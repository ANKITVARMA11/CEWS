# Data sources

Status: the collection framework is built (Phase 3). The source adapters themselves are built
in Phase 4, so `python scripts/fetch_all.py` currently reports every source as skipped with
"no adapter implemented yet".

## Sources at a glance

| Source | Data | On by default | Key needed | Status |
|---|---|---|---|---|
| ClinicalTrials.gov | Clinical trials | yes | no | Adapter in Phase 4 |
| PubMed | Publications | yes | optional (`NCBI_API_KEY`) | Adapter in Phase 4 |
| Europe PMC | Publications | yes | no | Adapter in Phase 4 |
| Company / investor-relations RSS | Announcements | yes (no feeds listed yet) | no | Adapter in Phase 4; add feed URLs to the registry |
| NIH RePORTER | Grants and funding | no | no | Adapter after the MVP |
| OpenAlex | Publications | no | **yes, required since Feb 2026** | Off until pricing is confirmed free |
| USPTO Open Data Portal | Patents | no | may be required | **Blocked**: PatentsView migration, see below |
| EPO Open Patent Services | Patents | no | yes (free registration) | Not built; only if credentials are provided later |

Removed from scope in the v2 plan: WHO ICTRP and EU trial registries, Crossref, bioRxiv.

## How collection works

Each source is one adapter class plugged into a shared framework (`src/cews/ingestion/`).
Configuration lives in `config/source_registry.yaml` (rate limit, page size, page cap, date-slice
length, refresh mode) and the `ENABLE_*` flags in `.env`. No code change is needed to tune them.

1. **Plan.** Each run reads the source's checkpoint. The first run collects the full lookback
   (`DEFAULT_LOOKBACK_DAYS`). Later runs start at the last watermark minus
   `INCREMENTAL_LOOKBACK_DAYS`, so late updates are caught; upserts make the overlap harmless.
   Sources with `refresh.mode: full` (patents, funding) are checked every cycle but only
   collected when their refresh window is due.
2. **Fetch.** The window is split into date slices and fetched page by page. Every request goes
   through a per-source rate limiter, retries timeouts, HTTP 429 and 5xx with exponential
   backoff (honouring `Retry-After`), and may only contact the hosts listed for that source.
3. **Store.** Each page is validated, de-duplicated and upserted in its own short transaction.
   One bad record is skipped and counted; it never stops the run.
4. **Checkpoint.** The watermark moves forward only over slices that finished completely. A
   failure, or reaching `max_pages_per_run`, leaves an unfinished checkpoint that the next run
   resumes, so no data is skipped.
5. **Protect.** After `CIRCUIT_BREAKER_FAILURE_THRESHOLD` failed runs in a row, a source is paused
   for `CIRCUIT_BREAKER_COOLDOWN_MINUTES`. One failing source never stops the others: sources run
   in parallel (`MAX_CONCURRENT_SOURCE_JOBS`) and each failure is isolated.
6. **Audit.** Every run writes an `ingestion_runs` row per source (counters, errors, checkpoint,
   rate-limit details) and a `job_runs` row for the whole fetch.

Commands:

```
python -m cews.cli sources            # each source: enabled, adapter ready, last success, state
python -m cews.cli sources --health   # also contact each enabled source
python scripts/fetch_all.py           # one manual fetch of all enabled sources
python scripts/fetch_all.py --dry-run # fetch and parse, write nothing
python scripts/fetch_all.py --source pubmed --full
```

Live data and demo data are never mixed: fetching into a database that holds synthetic demo data
is refused. Use a separate database for live data, for example `SQLITE_PATH=./data/cews_live.db`.

## Adding a source

Subclass `SourceAdapter`, set `source_name` and `source_type`, implement `build_query`,
`parse_response` and `normalize_record`, decorate the class with `@register_adapter`, add a
registry entry, and add a case to `tests/contract/test_source_adapter_contract.py` (a test fails
until you do). `tests/support_adapters.py` holds a complete reference adapter.

## Access risks checked on 2026-09-20

**Patents (PatentsView).** PatentsView migrated to the USPTO Open Data Portal (ODP,
https://data.uspto.gov) starting 2026-03-20. USPTO's transition guide
(https://data.uspto.gov/support/transition-guide/patentsview) says temporary interruptions
are expected for the PatentSearch API and that API functions will be reintroduced in updated
forms; bulk downloads are available on ODP. Some third-party tools report the legacy API as
shut down. Plan: do not build a live patents adapter on the old PatentsView endpoint. Start
with a fixture adapter, then target ODP bulk downloads, and re-check API status first.

**Publications (OpenAlex).** OpenAlex's deprecations page
(https://developers.openalex.org/guides/deprecations) states that the polite pool was
replaced by API keys in February 2026: `mailto` is ignored and all users need a free API key.
A secondary source also reports usage-based pricing with a small daily free allowance; verify
this against OpenAlex's official pricing page before enabling the adapter, because the project
must stay free. Plan: OpenAlex is optional and off by default; Europe PMC is the third
no-key publication source in the MVP.

## Not yet verified

ClinicalTrials.gov, PubMed, Europe PMC, NIH RePORTER and RSS endpoints, terms, and rate limits
are taken from memory of public documentation and must be re-checked against the official
documentation when each adapter is built.
