"""Integration tests for the command-line interface (each test uses its own project root)."""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import func, select

from cews import __version__
from cews.cli import EXIT_CONFIG, EXIT_FAILURE, EXIT_OK, main
from cews.database.connection import create_db_engine, create_session_factory, session_scope
from cews.database.migrations import head_revision
from cews.database.models import SourceRecord, Topic
from cews.database.repositories import SourceRecordData, upsert_source_record
from support import REGISTRY_FILE, SCORING_FILE, TAXONOMY_FILE

pytestmark = pytest.mark.integration


@pytest.fixture
def env_file(tmp_path: Path) -> Path:
    path = tmp_path / ".env"
    path.write_text(
        f"PROJECT_ROOT={tmp_path}\nSQLITE_PATH=./data/cews.db\n"
        f"TOPIC_TAXONOMY_FILE={TAXONOMY_FILE}\nSCORING_CONFIG_FILE={SCORING_FILE}\n"
        f"SOURCE_REGISTRY_FILE={REGISTRY_FILE}\n",
        encoding="utf-8",
    )
    return path


def _run(env_file: Path, *args: str) -> int:
    command, *rest = args
    return main([command, "--env-file", str(env_file), *rest])


def test_version_flag(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as excinfo:
        main(["--version"])
    assert excinfo.value.code == 0
    assert __version__ in capsys.readouterr().out


def test_check_env_before_and_after_init(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(env_file, "check-env") == EXIT_OK
    out = capsys.readouterr().out
    assert "configuration is valid" in out and "not created yet" in out
    assert _run(env_file, "db-init") == EXIT_OK
    capsys.readouterr()
    assert _run(env_file, "check-env") == EXIT_OK
    assert "database reachable" in capsys.readouterr().out


def test_db_init_creates_schema_and_taxonomy(
    env_file: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(env_file, "db-init") == EXIT_OK
    out = capsys.readouterr().out
    assert f"revision {head_revision()}" in out and "8 topic(s)" in out
    assert (tmp_path / "data" / "cews.db").is_file()
    assert _run(env_file, "db-init") == EXIT_OK  # idempotent
    assert "0 topic(s)" in capsys.readouterr().out


def test_db_init_can_skip_taxonomy(env_file: Path, tmp_path: Path) -> None:
    assert _run(env_file, "db-init", "--no-taxonomy") == EXIT_OK
    factory = create_session_factory(create_db_engine(f"sqlite:///{tmp_path / 'data' / 'cews.db'}"))
    with session_scope(factory) as session:
        assert session.scalar(select(func.count()).select_from(Topic)) == 0


def test_db_status_reports_counts(env_file: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert _run(env_file, "db-status") == EXIT_FAILURE  # not initialized yet
    assert "run db-init" in capsys.readouterr().out
    _run(env_file, "db-init")
    _run(env_file, "seed-demo", "--scale", "0.1")
    capsys.readouterr()
    assert _run(env_file, "db-status") == EXIT_OK
    out = capsys.readouterr().out
    assert "up to date" in out and "synthetic" in out and "last run" in out


def test_seed_requires_an_initialized_database(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(env_file, "seed-demo") == EXIT_FAILURE
    assert "run db-init first" in capsys.readouterr().out


def test_seed_is_idempotent_and_labelled(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _run(env_file, "db-init")
    capsys.readouterr()
    assert _run(env_file, "seed-demo", "--scale", "0.1") == EXIT_OK
    first = capsys.readouterr().out
    assert "SYNTHETIC" in first and "inserted" in first
    assert _run(env_file, "seed-demo", "--scale", "0.1") == EXIT_OK
    assert "0 inserted, 0 updated" in capsys.readouterr().out


def test_seed_writes_fixture_files(env_file: Path, tmp_path: Path) -> None:
    _run(env_file, "db-init")
    assert _run(env_file, "seed-demo", "--scale", "0.1", "--write-fixtures") == EXIT_OK
    written = sorted(p.name for p in (tmp_path / "data" / "samples" / "demo").iterdir())
    assert "scenarios.json" in written and "synthetic_patents.jsonl" in written


def test_seed_refuses_to_mix_with_live_data(
    env_file: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _run(env_file, "db-init")
    factory = create_session_factory(create_db_engine(f"sqlite:///{tmp_path / 'data' / 'cews.db'}"))
    from datetime import UTC, datetime

    with session_scope(factory) as session:
        upsert_source_record(
            session,
            SourceRecordData(
                source="pubmed",
                source_record_id="1",
                record_type="publication",
                content_hash="a" * 64,
                fetched_at=datetime(2026, 9, 1, tzinfo=UTC),
            ),
        )
    capsys.readouterr()
    assert _run(env_file, "seed-demo", "--scale", "0.1") == EXIT_FAILURE
    assert "refusing" in capsys.readouterr().out
    assert _run(env_file, "seed-demo", "--scale", "0.1", "--allow-mixed") == EXIT_OK


def test_reset_requires_confirmation_and_keeps_live_data(
    env_file: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _run(env_file, "db-init")
    _run(env_file, "seed-demo", "--scale", "0.1")
    capsys.readouterr()
    assert _run(env_file, "reset-demo") == EXIT_CONFIG
    assert "--yes" in capsys.readouterr().out
    factory = create_session_factory(create_db_engine(f"sqlite:///{tmp_path / 'data' / 'cews.db'}"))
    with session_scope(factory) as session:
        assert (session.scalar(select(func.count()).select_from(SourceRecord)) or 0) > 100
    assert _run(env_file, "reset-demo", "--yes") == EXIT_OK
    with session_scope(factory) as session:
        assert session.scalar(select(func.count()).select_from(SourceRecord)) == 0


def test_reset_on_missing_database_is_a_no_op(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(env_file, "reset-demo", "--yes") == EXIT_OK
    assert "nothing to reset" in capsys.readouterr().out


def test_invalid_configuration_exits_with_config_code(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    env_file.write_text(
        env_file.read_text(encoding="utf-8") + "FETCH_INTERVAL_MINUTES=0\n", encoding="utf-8"
    )
    assert _run(env_file, "check-env") == EXIT_CONFIG
    assert "FETCH_INTERVAL_MINUTES" in capsys.readouterr().out
    assert _run(env_file, "db-init") == EXIT_CONFIG


def test_missing_env_file_exits_with_config_code(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["db-init", "--env-file", str(tmp_path / "absent.env")]) == EXIT_CONFIG
    assert "not found" in capsys.readouterr().out


def test_invalid_demo_parameters_are_reported(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _run(env_file, "db-init")
    assert _run(env_file, "seed-demo", "--months", "3") == EXIT_FAILURE
    assert "months must be" in capsys.readouterr().out


# --------------------------------------------------------------------------------------
# sources and fetch (Phase 3: the framework exists, no real adapter is registered yet)
# --------------------------------------------------------------------------------------
def test_sources_lists_the_registry(env_file: Path, capsys: pytest.CaptureFixture[str]) -> None:
    _run(env_file, "db-init")
    capsys.readouterr()
    assert _run(env_file, "sources") == EXIT_OK
    out = capsys.readouterr().out
    for source in ("clinical_trials_gov", "pubmed", "europe_pmc", "openalex", "patents_uspto_bulk"):
        assert source in out
    assert "not yet" in out and "never run" in out


def test_sources_works_before_db_init(env_file: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert _run(env_file, "sources") == EXIT_OK
    assert "never run" in capsys.readouterr().out


def test_sources_health_without_adapters_makes_no_requests(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(env_file, "sources", "--health") == EXIT_OK
    assert "no adapter yet" in capsys.readouterr().out


def test_fetch_requires_an_initialized_database(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert _run(env_file, "fetch") == EXIT_FAILURE
    assert "db-init" in capsys.readouterr().out


def test_fetch_skips_sources_without_adapters(
    env_file: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _run(env_file, "db-init")
    _run(env_file, "seed-demo", "--scale", "0.1")  # demo data must not block a no-op fetch
    capsys.readouterr()
    assert _run(env_file, "fetch") == EXIT_OK
    out = capsys.readouterr().out
    assert "no adapter implemented yet" in out
    assert "Result: skipped (0 of 4 source(s) ran)" in out


def test_fetch_dry_run_and_explicit_disabled_source(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _run(env_file, "db-init")
    capsys.readouterr()
    assert _run(env_file, "fetch", "--dry-run", "--source", "openalex") == EXIT_OK
    out = capsys.readouterr().out
    assert "dry run" in out and "ENABLE_OPENALEX=false" in out


def test_fetch_unknown_source_is_a_usage_error(
    env_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _run(env_file, "db-init")
    capsys.readouterr()
    assert _run(env_file, "fetch", "--source", "nope") == EXIT_CONFIG
    assert "unknown source" in capsys.readouterr().out
