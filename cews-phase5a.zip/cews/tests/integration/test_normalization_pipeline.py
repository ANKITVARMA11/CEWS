"""Integration tests for the normalization pipeline and competitor discovery."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime
from typing import Any

import pytest
from sqlalchemy import Engine, func, select
from sqlalchemy.orm import Session, sessionmaker

from cews.constants import ProcessingStatus, RelationshipType
from cews.database.connection import create_memory_engine, create_session_factory, session_scope
from cews.database.migrations import upgrade_database
from cews.database.models import (
    Organization,
    RecordOrganization,
    RecordTopic,
    ReviewQueueItem,
    SourceRecord,
    Topic,
)
from cews.demo.generator import DemoConfig, generate_demo_dataset
from cews.demo.loader import load_demo_dataset
from cews.normalization.pipeline import (
    deduplicate_records,
    normalize_records,
    reset_normalization,
)
from cews.normalization.topics import Taxonomy, load_taxonomy, sync_taxonomy
from cews.settings import Settings, load_settings
from support import TAXONOMY_FILE

pytestmark = pytest.mark.integration

AS_OF = datetime(2026, 9, 1, tzinfo=UTC)


@pytest.fixture(scope="module")
def taxonomy() -> Taxonomy:
    return load_taxonomy(TAXONOMY_FILE)


@pytest.fixture
def factory() -> Iterator[sessionmaker[Session]]:
    engine: Engine = create_memory_engine()
    upgrade_database(engine)
    yield create_session_factory(engine)
    engine.dispose()


@pytest.fixture
def settings() -> Settings:
    return load_settings(
        env_file=None,
        overrides={"topic_taxonomy_file": TAXONOMY_FILE, "min_competitor_evidence_count": 5},
    )


@pytest.fixture
def loaded(factory: sessionmaker[Session], taxonomy: Taxonomy) -> sessionmaker[Session]:
    with session_scope(factory) as session:
        sync_taxonomy(session, taxonomy)
        load_demo_dataset(session, generate_demo_dataset(DemoConfig(scale=0.2)))
    return factory


def _count(factory: sessionmaker[Session], model: type, **where: Any) -> int:
    with session_scope(factory) as session:
        query = select(func.count()).select_from(model)
        for name, value in where.items():
            query = query.where(getattr(model, name) == value)
        return int(session.scalar(query) or 0)


# --------------------------------------------------------------------------------------
# Pipeline
# --------------------------------------------------------------------------------------
def test_records_are_linked_to_organizations_and_topics(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        summary = normalize_records(session, settings, taxonomy)
    assert summary.records_processed > 200 and summary.failures == 0
    assert summary.organization_links >= summary.records_processed
    assert summary.topic_links > 0
    assert _count(loaded, SourceRecord, processing_status=ProcessingStatus.NORMALIZED.value) == (
        summary.records_processed
    )
    # every demo company is found, and nothing is invented
    with session_scope(loaded) as session:
        names = {o.canonical_name for o in session.scalars(select(Organization))}
    assert "Zentavia Pharmaceuticals Ltd" in names or "Zentavia Pharma" in names
    assert any("Orvexa" in name for name in names)


def test_running_twice_adds_nothing(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        first = normalize_records(session, settings, taxonomy)
    links = _count(loaded, RecordOrganization)
    with session_scope(loaded) as session:
        second = normalize_records(session, settings, taxonomy)
    assert second.records_processed == 0
    assert _count(loaded, RecordOrganization) == links
    assert first.records_processed > 0


def test_reprocessing_reuses_the_existing_organizations(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        normalize_records(session, settings, taxonomy)
    organizations = _count(loaded, Organization)
    links = _count(loaded, RecordOrganization)
    with session_scope(loaded) as session:
        reset_normalization(session)
        again = normalize_records(session, settings, taxonomy, reprocess=True)
    assert again.records_processed > 0 and again.organizations_created == 0
    assert _count(loaded, Organization) == organizations
    assert _count(loaded, RecordOrganization) == links


def test_a_limit_processes_only_part_of_the_backlog(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        summary = normalize_records(session, settings, taxonomy, limit=25)
    assert summary.records_processed == 25
    assert _count(loaded, SourceRecord, processing_status=ProcessingStatus.NEW.value) > 0


def test_relationship_types_and_confidence_reflect_the_evidence(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        normalize_records(session, settings, taxonomy)
    with session_scope(loaded) as session:
        rows = session.execute(
            select(
                RecordOrganization.relationship_type,
                func.min(RecordOrganization.confidence),
                func.max(RecordOrganization.confidence),
            ).group_by(RecordOrganization.relationship_type)
        ).all()
    by_type = {name: (low, high) for name, low, high in rows}
    assert RelationshipType.SPONSOR.value in by_type
    assert by_type[RelationshipType.SPONSOR.value][1] >= 0.9  # sponsoring is strong evidence
    if RelationshipType.AFFILIATION.value in by_type:
        # an author's affiliation is weak evidence and must never outrank sponsorship
        assert by_type[RelationshipType.AFFILIATION.value][1] <= 0.55


def test_topic_assignments_carry_their_confidence(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        normalize_records(session, settings, taxonomy)
    with session_scope(loaded) as session:
        rows = session.execute(
            select(Topic.key, func.count(RecordTopic.id))
            .join(RecordTopic, RecordTopic.topic_id == Topic.id)
            .group_by(Topic.key)
        ).all()
        confidences = session.scalars(select(RecordTopic.confidence)).all()
    assigned = dict(rows)
    assert "crispr_gene_editing" in assigned
    assert all(0 < value <= 0.95 for value in confidences)


def test_records_matching_no_topic_are_counted_not_forced(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        summary = normalize_records(session, settings, taxonomy)
    # the demo contains a topic the taxonomy deliberately lacks; those records stay untagged
    assert summary.records_without_topic > 0


def test_a_broken_record_does_not_stop_the_pass(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        record = session.scalars(select(SourceRecord).limit(1)).one()
        record.raw_payload_json = {"protocolSection": "not a mapping"}
        record.title = None
    with session_scope(loaded) as session:
        summary = normalize_records(session, settings, taxonomy)
    assert summary.records_processed > 0
    assert summary.failures + summary.records_processed > 200


def test_uncertain_names_are_queued_for_review(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        normalize_records(session, settings, taxonomy)
    with session_scope(loaded) as session:
        items = session.scalars(select(ReviewQueueItem)).all()
        pairs = [i.payload_json.get("organizations") for i in items if i.payload_json]
    assert items
    # the look-alike companies are surfaced for a human, not merged
    assert any(pair and "Orvexa" in str(pair) for pair in pairs)


def test_duplicate_detection_is_idempotent(
    loaded: sessionmaker[Session], settings: Settings, taxonomy: Taxonomy
) -> None:
    with session_scope(loaded) as session:
        normalize_records(session, settings, taxonomy)
    with session_scope(loaded) as session:
        first = deduplicate_records(session)
        second = deduplicate_records(session)
    assert first.duplicates == second.duplicates
    assert second.cleared == 0
