"""Unit tests for the job lock and persisted job history."""

from __future__ import annotations

import threading
import time
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from sqlalchemy.orm import Session, sessionmaker

from cews.constants import RunStatus
from cews.database.connection import create_db_engine, create_session_factory, session_scope
from cews.database.migrations import upgrade_database
from cews.database.models import JobLock, JobRun
from cews.scheduler.job_state import (
    INTERRUPTED,
    JobAlreadyRunningError,
    acquire_lock,
    consecutive_failures,
    finish_job_run,
    job_lock,
    last_success,
    lock_holder,
    mark_interrupted_runs,
    recent_job_runs,
    release_lock,
    renew_lock,
    start_job_run,
)
from cews.settings import load_settings

pytestmark = pytest.mark.unit

T0 = datetime(2026, 9, 1, 12, 0, tzinfo=UTC)
TTL = timedelta(minutes=10)


@pytest.fixture
def factory(tmp_path: Path) -> Iterator[sessionmaker[Session]]:
    """A file database: the lock is about separate connections, which an in-memory one hides."""
    settings = load_settings(
        env_file=None, overrides={"project_root": tmp_path, "sqlite_path": Path("./jobs.db")}
    )
    engine = create_db_engine(settings)
    upgrade_database(engine)
    yield create_session_factory(engine)
    engine.dispose()


# --------------------------------------------------------------------------------------
# The lock
# --------------------------------------------------------------------------------------
def test_a_free_lock_can_be_taken(factory: sessionmaker[Session]) -> None:
    assert acquire_lock(factory, "refresh", "a", TTL, now=T0) is True
    holder = lock_holder(factory, "refresh", now=T0)
    assert holder is not None and holder["owner"] == "a"


def test_a_held_lock_cannot_be_taken_by_someone_else(factory: sessionmaker[Session]) -> None:
    assert acquire_lock(factory, "refresh", "a", TTL, now=T0)
    assert acquire_lock(factory, "refresh", "b", TTL, now=T0 + timedelta(minutes=1)) is False
    holder = lock_holder(factory, "refresh", now=T0)
    assert holder is not None and holder["owner"] == "a"


def test_different_names_do_not_block_each_other(factory: sessionmaker[Session]) -> None:
    assert acquire_lock(factory, "refresh", "a", TTL, now=T0)
    assert acquire_lock(factory, "other", "b", TTL, now=T0)


def test_an_expired_lock_is_taken_over(factory: sessionmaker[Session]) -> None:
    """A crashed process must not block every later run forever."""
    assert acquire_lock(factory, "refresh", "crashed", TTL, now=T0)
    later = T0 + TTL + timedelta(seconds=1)
    assert lock_holder(factory, "refresh", now=later) is None
    assert acquire_lock(factory, "refresh", "fresh", TTL, now=later) is True
    holder = lock_holder(factory, "refresh", now=later)
    assert holder is not None and holder["owner"] == "fresh"


def test_a_lock_that_has_not_quite_expired_still_holds(factory: sessionmaker[Session]) -> None:
    assert acquire_lock(factory, "refresh", "a", TTL, now=T0)
    assert acquire_lock(factory, "refresh", "b", TTL, now=T0 + TTL - timedelta(seconds=1)) is False


def test_only_the_owner_can_renew(factory: sessionmaker[Session]) -> None:
    acquire_lock(factory, "refresh", "a", TTL, now=T0)
    assert renew_lock(factory, "refresh", "b", TTL, now=T0) is False
    assert renew_lock(factory, "refresh", "a", TTL, now=T0 + timedelta(minutes=8)) is True
    assert acquire_lock(factory, "refresh", "b", TTL, now=T0 + timedelta(minutes=12)) is False


def test_renewing_after_losing_the_lock_reports_it(factory: sessionmaker[Session]) -> None:
    acquire_lock(factory, "refresh", "a", TTL, now=T0)
    later = T0 + TTL + timedelta(seconds=1)
    assert acquire_lock(factory, "refresh", "b", TTL, now=later)
    assert renew_lock(factory, "refresh", "a", TTL, now=later) is False


def test_only_the_owner_can_release(factory: sessionmaker[Session]) -> None:
    acquire_lock(factory, "refresh", "a", TTL, now=T0)
    release_lock(factory, "refresh", "b")
    assert lock_holder(factory, "refresh", now=T0) is not None
    release_lock(factory, "refresh", "a")
    assert lock_holder(factory, "refresh", now=T0) is None


def test_exactly_one_of_many_simultaneous_callers_gets_the_lock(
    factory: sessionmaker[Session],
) -> None:
    """The point of a lock: a real race, from many threads, has one winner."""
    winners: list[str] = []
    barrier = threading.Barrier(8)

    def contend(name: str) -> None:
        barrier.wait()
        if acquire_lock(factory, "refresh", name, TTL):
            winners.append(name)

    threads = [threading.Thread(target=contend, args=(f"t{i}",)) for i in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=30)
    assert len(winners) == 1
    with session_scope(factory) as session:
        assert session.query(JobLock).count() == 1


# --------------------------------------------------------------------------------------
# The context manager
# --------------------------------------------------------------------------------------
def test_the_lock_is_held_inside_the_block_and_released_after(
    factory: sessionmaker[Session],
) -> None:
    with job_lock(factory, "refresh"):
        assert lock_holder(factory, "refresh") is not None
    assert lock_holder(factory, "refresh") is None


def test_a_second_holder_is_refused_with_a_clear_message(factory: sessionmaker[Session]) -> None:
    with (
        job_lock(factory, "refresh"),
        pytest.raises(JobAlreadyRunningError, match="already running"),
        job_lock(factory, "refresh"),
    ):
        pass


def test_the_lock_is_released_when_the_block_fails(factory: sessionmaker[Session]) -> None:
    with pytest.raises(RuntimeError, match="boom"), job_lock(factory, "refresh"):
        raise RuntimeError("boom")
    assert lock_holder(factory, "refresh") is None


def test_the_heartbeat_keeps_a_long_cycle_from_losing_its_lock(
    factory: sessionmaker[Session],
) -> None:
    """Without it, a cycle running longer than the expiry would be open to a second one."""
    with job_lock(factory, "refresh", timedelta(seconds=0.4), heartbeat_seconds=0.05):
        time.sleep(1.0)  # far longer than the 0.4 s expiry
        assert lock_holder(factory, "refresh") is not None
        assert acquire_lock(factory, "refresh", "intruder", TTL) is False


def test_without_a_heartbeat_the_same_lock_would_have_expired(
    factory: sessionmaker[Session],
) -> None:
    assert acquire_lock(factory, "refresh", "a", timedelta(seconds=0.2))
    time.sleep(0.5)
    assert lock_holder(factory, "refresh") is None


def test_the_heartbeat_stops_when_the_block_ends(factory: sessionmaker[Session]) -> None:
    before = {t.name for t in threading.enumerate()}
    with job_lock(factory, "refresh", timedelta(seconds=1), heartbeat_seconds=0.05):
        assert any(t.name == "cews-lock-refresh" for t in threading.enumerate())
    time.sleep(0.2)
    assert not any(t.name == "cews-lock-refresh" for t in threading.enumerate())
    assert {t.name for t in threading.enumerate()} <= before | {"MainThread"}


# --------------------------------------------------------------------------------------
# Persisted history
# --------------------------------------------------------------------------------------
def test_a_run_is_recorded_from_start_to_finish(factory: sessionmaker[Session]) -> None:
    job_id = start_job_run(factory, "refresh", trigger="schedule", now=T0)
    with session_scope(factory) as session:
        row = session.query(JobRun).one()
        assert row.status == "running" and row.trigger == "schedule" and row.finished_at is None
    finish_job_run(
        factory, job_id, RunStatus.SUCCEEDED, summary={"steps": 3}, now=T0 + timedelta(minutes=5)
    )
    with session_scope(factory) as session:
        row = session.query(JobRun).one()
        assert row.status == "succeeded" and row.summary_json == {"steps": 3}
        assert row.finished_at is not None


def test_a_failure_keeps_its_reason(factory: sessionmaker[Session]) -> None:
    job_id = start_job_run(factory, "refresh", trigger="manual")
    finish_job_run(factory, job_id, RunStatus.FAILED, error="step 'score' failed")
    with session_scope(factory) as session:
        assert session.query(JobRun).one().error_summary == "step 'score' failed"


def test_runs_left_marked_running_by_a_dead_process_are_closed(
    factory: sessionmaker[Session],
) -> None:
    stale = start_job_run(factory, "refresh", trigger="schedule", now=T0)
    other = start_job_run(factory, "fetch", trigger="manual", now=T0)  # a different kind of job
    done = start_job_run(factory, "refresh", trigger="manual", now=T0)
    finish_job_run(factory, done, RunStatus.SUCCEEDED)
    assert mark_interrupted_runs(factory, "refresh", now=T0 + timedelta(hours=1)) == 1
    with session_scope(factory) as session:
        rows = {r.job_id: r for r in session.query(JobRun)}
    assert rows[stale].status == "failed" and rows[stale].error_summary == INTERRUPTED
    assert rows[other].status == "running"  # not this job's, so left alone
    assert rows[done].status == "succeeded"


def test_recent_runs_are_newest_first_limited_and_filterable(
    factory: sessionmaker[Session],
) -> None:
    for index in range(5):
        start_job_run(factory, "refresh", trigger="schedule", now=T0 + timedelta(hours=index))
    start_job_run(factory, "fetch", trigger="manual", now=T0 + timedelta(hours=9))
    with session_scope(factory) as session:
        runs = recent_job_runs(session, job_name="refresh", limit=3)
        assert [r.started_at.hour for r in runs] == [16, 15, 14]
        assert recent_job_runs(session, limit=100)[0].job_name == "fetch"


def test_the_last_success_ignores_failures_and_running_runs(factory: sessionmaker[Session]) -> None:
    ok = start_job_run(factory, "refresh", trigger="schedule", now=T0)
    finish_job_run(factory, ok, RunStatus.SUCCEEDED)
    bad = start_job_run(factory, "refresh", trigger="schedule", now=T0 + timedelta(hours=2))
    finish_job_run(factory, bad, RunStatus.FAILED)
    start_job_run(
        factory, "refresh", trigger="schedule", now=T0 + timedelta(hours=4)
    )  # still running
    with session_scope(factory) as session:
        success = last_success(session)
        assert success is not None and success.job_id == ok


def test_no_success_at_all_is_none(factory: sessionmaker[Session]) -> None:
    with session_scope(factory) as session:
        assert last_success(session) is None


def test_consecutive_failures_count_back_to_the_last_non_failure(
    factory: sessionmaker[Session],
) -> None:
    def add(status: RunStatus, hours: int) -> None:
        job_id = start_job_run(
            factory, "refresh", trigger="schedule", now=T0 + timedelta(hours=hours)
        )
        finish_job_run(factory, job_id, status)

    add(RunStatus.SUCCEEDED, 0)
    add(RunStatus.FAILED, 1)
    add(RunStatus.FAILED, 2)
    add(RunStatus.PARTIAL, 3)  # a partial run is not a failure and ends the streak
    add(RunStatus.FAILED, 4)
    add(RunStatus.FAILED, 5)
    add(RunStatus.FAILED, 6)
    with session_scope(factory) as session:
        assert consecutive_failures(session) == 3


def test_a_latest_success_means_no_failing_streak(factory: sessionmaker[Session]) -> None:
    for hours, status in ((0, RunStatus.FAILED), (1, RunStatus.SUCCEEDED)):
        job_id = start_job_run(
            factory, "refresh", trigger="schedule", now=T0 + timedelta(hours=hours)
        )
        finish_job_run(factory, job_id, status)
    with session_scope(factory) as session:
        assert consecutive_failures(session) == 0
