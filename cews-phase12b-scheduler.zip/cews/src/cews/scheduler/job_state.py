"""Job locks and persisted job history.

Two cycles must never run at once: they would fight over the same database and double-write
the same records. A **lock** lives in the database (``job_locks``), not in the process, so it
holds across a scheduler, a manual ``cews refresh`` typed in another terminal, and any future API
call. A lock has an expiry, renewed as a cycle makes progress, so one left behind by a crashed
process frees itself instead of blocking every later run forever.

Every cycle also leaves an audit row (``job_runs``) with its outcome, so what the scheduler did,
and when it last succeeded, survives a restart.
"""

from __future__ import annotations

import logging
import threading
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import delete, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, sessionmaker

from cews.constants import RunStatus
from cews.database.connection import session_scope
from cews.database.models import JobLock, JobRun

LOGGER = logging.getLogger(__name__)

REFRESH_JOB = "refresh"
REFRESH_LOCK = "refresh"
DEFAULT_LOCK_TTL = timedelta(minutes=10)
INTERRUPTED = "interrupted: the process stopped before this run finished"


class JobAlreadyRunningError(RuntimeError):
    """Raised when a cycle is asked to start while another still holds the lock."""

    def __init__(self, name: str, owner: str, expires_at: datetime) -> None:
        super().__init__(
            f"{name!r} is already running (held by {owner}, until {expires_at:%Y-%m-%d %H:%M} UTC)"
        )
        self.name, self.owner, self.expires_at = name, owner, expires_at


def _now() -> datetime:
    return datetime.now(UTC)


def _aware(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=UTC)


@dataclass
class LockHandle:
    """A held lock. Call :meth:`renew` between long steps so it does not expire mid-cycle."""

    factory: sessionmaker[Session]
    name: str
    owner: str
    ttl: timedelta

    def renew(self) -> bool:
        """Extend the expiry. Returns False if the lock was lost (expired and taken over)."""
        return renew_lock(self.factory, self.name, self.owner, self.ttl)


_HELD: list[LockHandle] = []  # locks held by this process right now
_HELD_GUARD = threading.Lock()


def held_lock_count() -> int:
    """How many locks this process holds right now (that is, whether a cycle is in flight)."""
    with _HELD_GUARD:
        return len(_HELD)


def release_held_locks() -> int:
    """Release every lock this process holds. Returns how many.

    For use only when the process is about to exit without letting its cycle finish (a second
    Ctrl+C): releasing a lock while its cycle still runs would let another start beside it. A run
    left marked running is closed as interrupted by the next cycle.
    """
    with _HELD_GUARD:
        handles, _HELD[:] = list(_HELD), []
    for handle in handles:
        try:
            release_lock(handle.factory, handle.name, handle.owner)
        except Exception:
            LOGGER.exception("could not release the %r lock while stopping", handle.name)
    return len(handles)


def acquire_lock(
    factory: sessionmaker[Session],
    name: str,
    owner: str,
    ttl: timedelta = DEFAULT_LOCK_TTL,
    *,
    now: datetime | None = None,
) -> bool:
    """Take the lock if it is free or has expired. Returns whether this caller now holds it.

    An expired lock is removed first, so a crashed holder never blocks anyone past its expiry.
    Two callers racing for a free lock cannot both win: the name is the primary key, so the
    second insert fails.
    """
    moment = now or _now()
    try:
        with session_scope(factory) as session:
            session.execute(
                delete(JobLock).where(JobLock.name == name, JobLock.expires_at <= moment)
            )
            session.add(
                JobLock(name=name, owner=owner, acquired_at=moment, expires_at=moment + ttl)
            )
            session.flush()
    except IntegrityError:
        return False
    return True


def renew_lock(
    factory: sessionmaker[Session],
    name: str,
    owner: str,
    ttl: timedelta = DEFAULT_LOCK_TTL,
    *,
    now: datetime | None = None,
) -> bool:
    """Push the expiry forward, only if ``owner`` still holds the lock."""
    moment = now or _now()
    with session_scope(factory) as session:
        result = session.execute(
            update(JobLock)
            .where(JobLock.name == name, JobLock.owner == owner)
            .values(expires_at=moment + ttl)
        )
    return bool(getattr(result, "rowcount", 0))


def release_lock(factory: sessionmaker[Session], name: str, owner: str) -> None:
    """Give the lock up. Releasing a lock someone else now holds does nothing."""
    with session_scope(factory) as session:
        session.execute(delete(JobLock).where(JobLock.name == name, JobLock.owner == owner))


def lock_holder(
    factory: sessionmaker[Session], name: str, *, now: datetime | None = None
) -> dict[str, Any] | None:
    """Who holds the lock right now, or None if it is free or has expired."""
    moment = now or _now()
    with session_scope(factory) as session:
        row = session.get(JobLock, name)
        if row is None or _aware(row.expires_at) <= moment:
            return None
        return {
            "name": row.name,
            "owner": row.owner,
            "acquired_at": _aware(row.acquired_at),
            "expires_at": _aware(row.expires_at),
        }


@contextmanager
def job_lock(
    factory: sessionmaker[Session],
    name: str,
    ttl: timedelta = DEFAULT_LOCK_TTL,
    *,
    heartbeat_seconds: float | None = None,
) -> Iterator[LockHandle]:
    """Hold the named lock for the duration of a ``with`` block.

    The expiry is short (so a crashed process frees the lock quickly) and a background heartbeat
    keeps renewing it for as long as the block is still running (so a long cycle never loses it).

    Args:
        heartbeat_seconds: how often to renew (default: a third of the expiry).

    Raises:
        JobAlreadyRunningError: if another holder has it and it has not expired.
    """
    owner = uuid.uuid4().hex[:12]
    for _ in range(3):
        if acquire_lock(factory, name, owner, ttl):
            break
        holder = lock_holder(factory, name)
        if holder is not None:
            raise JobAlreadyRunningError(name, holder["owner"], holder["expires_at"])
        # The lock expired or was released between our attempt and our look: try again.
    else:
        raise JobAlreadyRunningError(name, "another process", _now())

    handle = LockHandle(factory, name, owner, ttl)
    with _HELD_GUARD:
        _HELD.append(handle)
    stop = threading.Event()
    interval = heartbeat_seconds if heartbeat_seconds is not None else ttl.total_seconds() / 3

    def beat() -> None:
        while not stop.wait(interval):
            try:
                if not handle.renew():
                    LOGGER.error("lost the %r lock while running; another cycle may start", name)
                    return
            except Exception:  # a database hiccup must not kill the heartbeat
                LOGGER.exception("could not renew the %r lock; will try again", name)

    thread = threading.Thread(target=beat, name=f"cews-lock-{name}", daemon=True)
    thread.start()
    try:
        yield handle
    finally:
        stop.set()
        thread.join(timeout=5)
        with _HELD_GUARD:
            if handle in _HELD:
                _HELD.remove(handle)
        release_lock(factory, name, owner)


# ----------------------------------------------------------------------------------------
# Persisted history
# ----------------------------------------------------------------------------------------
def start_job_run(
    factory: sessionmaker[Session],
    job_name: str,
    *,
    trigger: str,
    dry_run: bool = False,
    now: datetime | None = None,
) -> str:
    """Record that a cycle has started, and return its id."""
    job_id = uuid.uuid4().hex
    with session_scope(factory) as session:
        session.add(
            JobRun(
                job_id=job_id,
                job_name=job_name,
                trigger=trigger,
                status=RunStatus.RUNNING.value,
                dry_run=dry_run,
                started_at=now or _now(),
            )
        )
    return job_id


def finish_job_run(
    factory: sessionmaker[Session],
    job_id: str,
    status: RunStatus,
    *,
    summary: dict[str, Any] | None = None,
    error: str | None = None,
    now: datetime | None = None,
) -> None:
    """Record how a cycle ended."""
    with session_scope(factory) as session:
        row = session.scalars(select(JobRun).where(JobRun.job_id == job_id)).one()
        row.status = status.value
        row.finished_at = now or _now()
        row.summary_json = summary
        row.error_summary = error


def mark_interrupted_runs(
    factory: sessionmaker[Session], job_name: str, *, now: datetime | None = None
) -> int:
    """Close out runs still marked running whose process is gone.

    Only call this while holding the lock: if it is held, no other cycle can legitimately be
    running, so anything still marked running was left behind by a process that stopped.
    Returns how many were closed.
    """
    moment = now or _now()
    with session_scope(factory) as session:
        result = session.execute(
            update(JobRun)
            .where(JobRun.job_name == job_name, JobRun.status == RunStatus.RUNNING.value)
            .values(status=RunStatus.FAILED.value, finished_at=moment, error_summary=INTERRUPTED)
        )
    return int(getattr(result, "rowcount", 0) or 0)


def recent_job_runs(
    session: Session, *, job_name: str | None = None, limit: int = 10
) -> list[JobRun]:
    """The newest runs first, optionally of one kind."""
    query = select(JobRun).order_by(JobRun.started_at.desc(), JobRun.id.desc()).limit(limit)
    if job_name:
        query = query.where(JobRun.job_name == job_name)
    return list(session.scalars(query))


def last_success(session: Session, job_name: str = REFRESH_JOB) -> JobRun | None:
    """The most recent run of this kind that fully succeeded."""
    return session.scalars(
        select(JobRun)
        .where(JobRun.job_name == job_name, JobRun.status == RunStatus.SUCCEEDED.value)
        .order_by(JobRun.started_at.desc(), JobRun.id.desc())
        .limit(1)
    ).first()


def consecutive_failures(session: Session, job_name: str = REFRESH_JOB) -> int:
    """How many of the most recent finished runs failed in a row (0 if the latest succeeded)."""
    count = 0
    for run in recent_job_runs(session, job_name=job_name, limit=50):
        if run.status == RunStatus.RUNNING.value:
            continue
        if run.status != RunStatus.FAILED.value:
            break
        count += 1
    return count
