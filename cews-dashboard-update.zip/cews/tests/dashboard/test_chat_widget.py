"""Tests for the floating chat launcher embedded in the main dashboard.

The chat itself moved to its own standalone app (see ``test_chat_app.py``); all this file needs
to check is that the dashboard shows a link to it, that the link opens in a new tab, and that the
link carries over whichever ``.env`` the dashboard's sidebar is using - not any chat behaviour,
since none of that runs in this process any more.
"""

from __future__ import annotations

import sys
from pathlib import Path
from urllib.parse import quote

import pytest
from streamlit.testing.v1 import AppTest

pytestmark = pytest.mark.integration

APP = Path(__file__).resolve().parents[2] / "dashboards" / "streamlit" / "app.py"
if str(APP.parent) not in sys.path:
    sys.path.insert(0, str(APP.parent))


def start(env_file: Path) -> AppTest:
    app = AppTest.from_file(str(APP), default_timeout=120)
    app.session_state["env_file"] = str(env_file)
    return app.run()


def test_the_launcher_link_is_on_every_page_load(env_file: Path) -> None:
    app = start(env_file)
    assert not app.exception
    html = "".join(m.value for m in app.markdown)
    assert "st-key-cews-chat-launcher" in html


def test_the_launcher_opens_in_a_new_tab(env_file: Path) -> None:
    app = start(env_file)
    html = "".join(m.value for m in app.markdown)
    assert 'target="_blank"' in html


def test_the_launcher_points_at_the_configured_chat_host_and_port(env_file: Path) -> None:
    """Regression-shaped: the link must use the real `chat_host`/`chat_port` settings, not a
    hardcoded address, so changing CHAT_PORT in .env actually changes where the button points."""
    custom = env_file.with_name("custom_chat_port.env")
    custom.write_text(env_file.read_text(encoding="utf-8") + "\nCHAT_PORT=9999\n", encoding="utf-8")
    app = start(custom)
    html = "".join(m.value for m in app.markdown)
    assert "http://127.0.0.1:9999/" in html


def test_the_launcher_carries_the_env_file_along_in_the_link(env_file: Path) -> None:
    app = start(env_file)
    html = "".join(m.value for m in app.markdown)
    assert f"env_file={quote(str(env_file))}" in html


def test_the_floating_css_is_injected(env_file: Path) -> None:
    """Only checks the style rules are present - actual floating position was verified by
    rendering the real dashboard in a headless browser, not by this test."""
    app = start(env_file)
    css = "".join(m.value for m in app.markdown)
    assert "st-key-cews-chat-launcher" in css and "position: fixed" in css


def test_the_launcher_never_starts_an_agent_runtime(
    env_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The whole point of moving the chat out of this process: a dashboard page that never opens
    the chat must never pay for an MCP connection or an LLM client."""
    from components import chat_widget

    def fail_if_called(_env_file: str) -> None:
        raise AssertionError("the dashboard launcher must not start an AgentRuntime")

    monkeypatch.setattr(chat_widget, "_runtime", fail_if_called)
    app = start(env_file)
    assert not app.exception
