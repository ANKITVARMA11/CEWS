"""The CEWS Analyst chat, and the floating button that opens it in its own browser tab.

This file has two halves, each used by a different Streamlit script:

* :func:`render_chat_page` draws the full chat (upload, history, input, clear button) and is
  called by ``chat_app.py`` - a second, standalone Streamlit script, run on its own port, whose
  only job is this one page. Opening it gives a genuinely separate browser tab with its own
  session: the chat no longer shares a rerun cycle with the seven-page dashboard, so a long
  conversation never forces every chart on the dashboard to redraw, and vice versa.
* :func:`render_floating_launcher` draws only the small floating icon the main dashboard shows
  (``app.py``) - a plain link to the chat app's URL, opening in a new tab. It never touches
  :class:`~cews.agents.session.AgentRuntime` at all, so the dashboard page itself stays free of
  any MCP connection or LLM round trip; all of that lives in the chat app's own process instead.

**How the floating position works, since this is the one non-obvious trick in this file:**
Streamlit gives ``st.container(key=...)`` a CSS class of ``st-key-<key>`` on its outer element
(confirmed by rendering a real Streamlit app in a headless browser and inspecting the DOM before
writing this — see the note in the test file). That is an ordinary block element in the normal
page flow; setting ``position: fixed`` on it via one injected ``<style>`` block is enough to make
it float over the rest of the page, pinned to the browser viewport rather than the page's normal
layout. No JavaScript, no custom component, no iframe trick is needed for this.

Nothing here writes to CEWS's database. An attached document is read into text in memory
(:func:`cews.agents.documents.read_document`) and lives only in ``st.session_state`` for that
browser tab; the file's raw bytes are discarded the moment its text has been extracted.
"""

from __future__ import annotations

import logging
from urllib.parse import quote

import streamlit as st

from cews.agents.core import AgentReply, format_tool_call
from cews.agents.documents import DocumentReadError, read_document
from cews.agents.personas import ANALYST
from cews.agents.session import AgentRuntime, ChatSession, RuntimeNotReadyError
from cews.ai.llm import LLMError, llm_enabled
from cews.settings import Settings, load_settings, resolve_env_file

LOGGER = logging.getLogger(__name__)

LAUNCHER_KEY = "cews-chat-launcher"
STATE_SESSION = "cews_chat_session"
STATE_DOCUMENT_IDS = "cews_chat_document_ids"

# The launcher button only ever needs to float bottom-left and look like a round icon; it is no
# longer paired with a panel, since the chat itself now lives on its own page.
_ABOVE_STREAMLIT_SIDEBAR = 1_000_000
_LAUNCHER_CSS = f"""
<style>
div.st-key-{LAUNCHER_KEY} {{
    position: fixed;
    left: 20px;
    bottom: 20px;
    z-index: {_ABOVE_STREAMLIT_SIDEBAR};
}}
div.st-key-{LAUNCHER_KEY} a {{
    display: flex;
    align-items: center;
    justify-content: center;
    width: 56px;
    height: 56px;
    border-radius: 50%;
    font-size: 1.4rem;
    text-decoration: none;
    background: var(--primary-color, #0072B2);
    color: white !important;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
}}
</style>
"""


def chat_app_url(host: str, port: int, env_file: str) -> str:
    """The standalone chat app's URL, carrying the dashboard's own ``env_file`` along with it so
    both processes read the same configuration without the person having to type it twice."""
    url = f"http://{host}:{port}/"
    if env_file:
        url += f"?env_file={quote(env_file)}"
    return url


def render_floating_launcher(host: str, port: int, env_file: str) -> None:
    """Draw the floating button that opens the chat app in a new browser tab.

    Call once per dashboard page render. This never starts an :class:`AgentRuntime` or checks
    the database - it is just a link - so it costs nothing on pages that never open it.
    """
    st.markdown(_LAUNCHER_CSS, unsafe_allow_html=True)
    url = chat_app_url(host, port, env_file)
    with st.container(key=LAUNCHER_KEY):
        st.markdown(
            f'<a href="{url}" target="_blank" rel="noopener" title="Open the CEWS Analyst chat '
            f'in a new tab">💬</a>',
            unsafe_allow_html=True,
        )


@st.cache_resource(show_spinner=False)
def _runtime(env_file: str) -> AgentRuntime | None:
    """One :class:`AgentRuntime` per distinct ``env_file``, kept for the app's lifetime.

    Returns None (rather than raising) when no LLM is configured at all, so the rest of the
    page can show a plain "not set up" message instead of every rerun trying and failing to
    start a runtime that was never going to work.

    ``env_file`` (a plain string, the cache key ``@st.cache_resource`` hashes on) is loaded into
    settings here rather than the caller passing a ``Settings`` object in, so this cache never has
    to hash or compare a whole settings object - just the one string that actually varies.
    """
    settings = load_settings(env_file=resolve_env_file(env_file))
    if not llm_enabled(settings):
        return None
    runtime = AgentRuntime(settings, env_file=env_file or None)
    runtime.start(timeout=60)
    return runtime


def _ensure_state() -> ChatSession:
    if STATE_SESSION not in st.session_state:
        st.session_state[STATE_SESSION] = ChatSession(session_id="chat-app")
    if STATE_DOCUMENT_IDS not in st.session_state:
        st.session_state[STATE_DOCUMENT_IDS] = set()
    session: ChatSession = st.session_state[STATE_SESSION]
    return session


def _handle_upload(session: ChatSession, settings: Settings) -> None:
    uploaded = st.file_uploader(
        "Attach a document (private to this conversation; never sent to CEWS's database)",
        type=["pdf", "docx", "xlsx", "xlsm", "csv", "txt", "md"],
        key="cews_chat_upload",
    )
    if uploaded is None:
        return
    seen: set[str] = st.session_state[STATE_DOCUMENT_IDS]
    if uploaded.file_id in seen:
        return  # already processed this exact upload; a rerun must not re-read it
    try:
        document = read_document(
            uploaded.name, uploaded.getvalue(), char_limit=settings.agent_document_char_limit
        )
    except DocumentReadError as exc:
        st.error(str(exc))
        return
    session.documents.append(document)
    seen.add(uploaded.file_id)
    st.caption(document.note)


def _render_history(session: ChatSession) -> None:
    for index, turn in enumerate(session.history):
        with st.chat_message(turn["role"]):
            st.write(turn["content"])
            if turn["role"] == "assistant":
                # history holds one user + one assistant entry per turn, in that order, so the
                # assistant at position `index` is turn `index // 2` in tool_log - kept in step
                # with history by record_turn (see ChatSession). format_tool_call is the same
                # formatting `cews agent` itself prints, so the two never show different detail
                # for the same kind of thing.
                calls = session.tool_log[index // 2]
                if calls:
                    lines = "\n".join(f"- `{format_tool_call(call)}`" for call in calls)
                    st.caption(f"Checked:\n{lines}")


def _ask(runtime: AgentRuntime, session: ChatSession, message: str) -> AgentReply:
    document_note = session.document_context()
    try:
        return runtime.ask(ANALYST, message, history=session.history, document_note=document_note)
    except TimeoutError:
        return AgentReply(text="The analyst took too long to answer. Try a shorter question.")
    except RuntimeNotReadyError:
        return AgentReply(text="The chat agent is not ready yet. Try again in a moment.")
    except LLMError as exc:
        # A tool failing is fed back to the model as a normal tool result (see
        # cews.agents.core), so the model can react to it; the model itself being unreachable
        # has nothing left to feed the message to, so it is caught here instead and shown as an
        # ordinary chat reply rather than crashing the whole page.
        LOGGER.warning("LLM call failed during a chat turn: %s", exc)
        return AgentReply(text=f"I couldn't reach the language model: {exc}")


def render_chat_page(env_file: str) -> None:
    """Draw the full chat page: history, upload, input, clear button. Call once per page render.

    This is the whole content of ``chat_app.py``'s page; it has no open/close toggle of its own
    because the page itself is the thing that was opened.
    """
    session = _ensure_state()
    settings = load_settings(env_file=resolve_env_file(env_file))
    if not llm_enabled(settings):
        st.info(
            "No LLM is configured (`LLM_PROVIDER=none`), so the chat agent cannot run. "
            "Set `LLM_PROVIDER` and `LLM_MODEL` in your `.env` to use it."
        )
        return

    with st.spinner("Connecting to the CEWS server..."):
        runtime = _runtime(env_file)
    if runtime is None:  # llm_enabled changed between checks is the only realistic way here
        st.info("No LLM is configured, so the chat agent cannot run.")
        return

    _handle_upload(session, settings)
    _render_history(session)

    message = st.chat_input("Ask about trends, competitors or insights...")
    if message:
        with st.spinner("Thinking..."):
            reply = _ask(runtime, session, message)
        # record_turn saves which tools were used too, and _render_history (called again right
        # after this rerun) is what actually displays it - a caption drawn here, before rerun()
        # throws this script run away, would never be visible to a person.
        session.record_turn(message, reply)
        st.rerun()

    if st.button("Clear conversation", key="cews_chat_clear"):
        st.session_state[STATE_SESSION] = ChatSession(session_id="chat-app")
        st.session_state[STATE_DOCUMENT_IDS] = set()
        st.rerun()
