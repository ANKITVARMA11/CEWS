"""Command-line interface for CEWS.

Commands (also available as ``python scripts/<name>.py`` wrappers)::

    cews check-env                 validate configuration, packages and database access
    cews db-init                   create/upgrade the database schema and load the taxonomy
    cews db-status                 show schema revision and record counts
    cews seed-demo                 load deterministic synthetic demo data
    cews reset-demo --yes          delete all synthetic data (live data is never touched)
    cews sources [--health]        list sources, their adapters, checkpoints and circuit state
    cews fetch [--dry-run]         collect enabled sources once (the scheduler does this every
                                   FETCH_INTERVAL_MINUTES from Phase 12)

Exit codes: 0 success, 1 runtime failure, 2 configuration or usage problem.
"""

from __future__ import annotations

import argparse
import contextlib
import importlib
import json
import logging
import sys
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sqlalchemy import Engine, func, inspect, select

from cews import __version__
from cews.constants import DatabaseBackend, RunStatus
from cews.database.connection import (
    DatabaseError,
    build_database_url,
    create_db_engine,
    create_session_factory,
    database_is_initialized,
    describe_url,
    session_scope,
)
from cews.database.migrations import current_revision, head_revision, upgrade_database
from cews.database.models import IngestionRun, ReviewQueueItem, Topic
from cews.database.repositories import (
    MixedDataError,
    count_records_by_origin,
    reset_synthetic_data,
)
from cews.demo.generator import DemoConfig, generate_demo_dataset, write_fixtures
from cews.demo.loader import load_demo_dataset
from cews.discovery.competitor_discovery import discover_competitors
from cews.features.activity_counts import aggregate_monthly_activity
from cews.features.pipeline import compute_features
from cews.ingestion.base import adapter_classes
from cews.ingestion.checkpoints import read_checkpoint
from cews.ingestion.orchestrator import create_adapter, fetch_all_enabled_sources
from cews.ingestion.registry import RegistryError, load_source_registry
from cews.logging_config import configure_logging
from cews.normalization.pipeline import normalize_records, reset_normalization
from cews.normalization.topics import TaxonomyError, load_taxonomy, sync_taxonomy
from cews.scoring.config import ScoringConfigError
from cews.scoring.pipeline import run_scoring
from cews.settings import (
    Settings,
    SettingsError,
    load_settings,
    resolve_competitor_mode,
    validate_settings,
)

EXIT_OK, EXIT_FAILURE, EXIT_CONFIG = 0, 1, 2
LOW_CONFIDENCE = 60.0
REQUIRED_PACKAGES = ("pydantic", "pydantic_settings", "sqlalchemy", "alembic", "yaml", "tzdata")
MIN_PYTHON = (3, 11)


def _load(args: argparse.Namespace) -> Settings:
    settings = load_settings(env_file=args.env_file) if args.env_file else load_settings()
    configure_logging(settings)
    if not args.verbose:
        for handler in logging.getLogger("cews").handlers:
            if isinstance(handler, logging.StreamHandler) and not isinstance(
                handler, logging.FileHandler
            ):
                handler.setLevel(logging.WARNING)
    return settings


_created_engines: list[Engine] = []


def _engine(settings: Settings) -> Engine:
    """Create an engine that ``main`` disposes when the command finishes."""
    engine = create_db_engine(settings)
    _created_engines.append(engine)
    return engine


# --------------------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------------------
def cmd_check_env(args: argparse.Namespace) -> int:
    """Validate Python, packages, configuration and database reachability."""
    failures = 0

    def report(level: str, message: str) -> None:
        nonlocal failures
        if level == "fail":
            failures += 1
        print(f"[{level:>4}] {message}")

    version = sys.version_info
    if (version.major, version.minor) >= MIN_PYTHON:
        report("ok", f"Python {version.major}.{version.minor}.{version.micro}")
    else:
        report("fail", f"Python {version.major}.{version.minor} found; 3.11 or newer is required")
    for package in REQUIRED_PACKAGES:
        try:
            importlib.import_module(package)
        except ImportError:
            report(
                "fail",
                f"package '{package}' is not installed (python -m pip install -r requirements-dev.txt)",
            )
    if failures:
        return EXIT_CONFIG

    try:
        settings = _load(args)
        warnings = validate_settings(settings)
        plan = resolve_competitor_mode(settings)
    except SettingsError as exc:
        print(exc)
        return EXIT_CONFIG
    report("ok", "configuration is valid")
    report(
        "ok",
        f"fetch interval {settings.fetch_interval_minutes} minutes, scheduler "
        f"{'on' if settings.enable_scheduler else 'off'}",
    )
    report(
        "ok",
        f"competitor mode {plan.mode.value}: {len(plan.include)} fixed, "
        f"{plan.auto_slots} automatic slot(s)",
    )
    report("ok", f"enabled sources: {', '.join(settings.enabled_sources) or 'none'}")
    try:
        registry = load_source_registry(settings.source_registry_file)
        report("ok", f"source registry valid ({len(registry)} sources)")
    except RegistryError as exc:
        report("fail", str(exc))
    for warning in warnings:
        report("warn", warning)

    url = build_database_url(settings)
    if settings.database_backend is DatabaseBackend.SQLITE and not Path(str(url.database)).exists():
        report("warn", f"SQLite database not created yet ({describe_url(url)}); run db-init")
    else:
        try:
            engine = _engine(settings)
            with engine.connect():
                pass
            report("ok", f"database reachable ({describe_url(url)})")
        except Exception as exc:  # any driver error is a failed check
            report("fail", f"cannot connect to {describe_url(url)}: {exc}")
    return EXIT_FAILURE if failures else EXIT_OK


def cmd_db_init(args: argparse.Namespace) -> int:
    """Create or upgrade the schema, then load the topic taxonomy."""
    settings = _load(args)
    engine = _engine(settings)
    revision = upgrade_database(engine)
    print(f"database schema at revision {revision} ({describe_url(build_database_url(settings))})")
    if not args.no_taxonomy:
        taxonomy = load_taxonomy(settings.topic_taxonomy_file)
        with session_scope(create_session_factory(engine)) as session:
            summary = sync_taxonomy(session, taxonomy)
        print(
            f"taxonomy loaded: {summary.topics_created} topic(s) and {summary.areas_created} area(s) "
            f"created, {summary.aliases_created} alias(es) added"
        )
    return EXIT_OK


def cmd_db_status(args: argparse.Namespace) -> int:
    """Print schema revision and record counts."""
    settings = _load(args)
    engine = _engine(settings)
    url = describe_url(build_database_url(settings))
    if not database_is_initialized(engine):
        print(f"database not initialized ({url}); run db-init")
        return EXIT_FAILURE
    revision, head = current_revision(engine), head_revision()
    state = "up to date" if revision == head else f"behind head {head}; run db-init"
    print(f"database : {url}")
    print(f"revision : {revision} ({state})")
    print(f"tables   : {len(inspect(engine).get_table_names()) - 1}")
    with session_scope(create_session_factory(engine)) as session:
        counts = count_records_by_origin(session)
        print(f"records  : {counts['synthetic']} synthetic, {counts['live']} live")
        print(f"topics   : {session.scalar(select(func.count()).select_from(Topic))}")
        last = session.scalars(
            select(IngestionRun).order_by(IngestionRun.start_time.desc())
        ).first()
        if last is not None:
            print(f"last run : {last.source} {last.status} at {last.start_time.isoformat()}")
    return EXIT_OK


def cmd_seed_demo(args: argparse.Namespace) -> int:
    """Generate and load the synthetic demo dataset (idempotent)."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    config = DemoConfig(seed=args.seed, months=args.months, scale=args.scale)
    dataset = generate_demo_dataset(config)
    taxonomy = load_taxonomy(settings.topic_taxonomy_file)
    try:
        with session_scope(create_session_factory(engine)) as session:
            sync_taxonomy(session, taxonomy)
            summary = load_demo_dataset(session, dataset, allow_mixed=args.allow_mixed)
    except MixedDataError as exc:
        print(f"error: {exc}")
        return EXIT_FAILURE
    print("SYNTHETIC demo data loaded (invented organizations and artificial patterns)")
    print(
        f"  records: {summary.total} ({summary.inserted} inserted, {summary.updated} updated, "
        f"{summary.unchanged} unchanged)"
    )
    print(f"  by type: {dataset.count_by_type()}")
    print(f"  months : {dataset.months[0].isoformat()} to {dataset.months[-1].isoformat()}")
    if args.write_fixtures is not None:
        directory = Path(args.write_fixtures).expanduser()
        if not directory.is_absolute():
            directory = settings.project_root / directory
        written = write_fixtures(dataset, directory)
        print(f"  fixtures: {len(written)} files written to {directory}")
    return EXIT_OK


def cmd_reset_demo(args: argparse.Namespace) -> int:
    """Delete all synthetic rows. Live data is never touched."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; nothing to reset")
        return EXIT_OK
    factory = create_session_factory(engine)
    with session_scope(factory) as session:
        counts = count_records_by_origin(session)
    if not args.yes:
        print(
            f"This deletes {counts['synthetic']} synthetic records and all derived synthetic rows "
            f"({counts['live']} live records are kept). Re-run with --yes to confirm."
        )
        return EXIT_CONFIG
    with session_scope(factory) as session:
        removed = reset_synthetic_data(session)
    print("removed:", ", ".join(f"{name}={count}" for name, count in removed.items() if count))
    return EXIT_OK


def _when(value: object) -> str:
    return value.strftime("%Y-%m-%d %H:%M") if hasattr(value, "strftime") else "-"


def cmd_sources(args: argparse.Namespace) -> int:
    """List configured sources with adapter, checkpoint and circuit-breaker state."""
    settings = _load(args)
    registry = load_source_registry(settings.source_registry_file)
    implemented = adapter_classes()
    engine = _engine(settings)
    states = {}
    if database_is_initialized(engine):
        with session_scope(create_session_factory(engine)) as session:
            states = {c.id: read_checkpoint(session, c.id) for c in registry}
    now = datetime.now(UTC)
    header = f"{'source':<20} {'type':<15} {'enabled':<8} {'adapter':<9} {'refresh':<12} {'last success':<17} state"
    print(header)
    print("-" * len(header))
    for config in registry:
        state = states.get(config.id)
        refresh = (
            config.refresh_mode
            if config.refresh_mode == "incremental"
            else f"full/{config.full_refresh_window_days}d"
        )
        if state is not None and state.circuit_open(now):
            condition = f"paused until {_when(state.circuit_open_until)}"
        elif state is not None and state.consecutive_failures:
            condition = f"{state.consecutive_failures} failed run(s)"
        elif state is not None and state.last_status:
            condition = state.last_status
        else:
            condition = "never run"
        print(
            f"{config.id:<20} {config.source_type.value:<15} "
            f"{'yes' if config.is_enabled(settings) else 'no':<8} "
            f"{'yes' if config.id in implemented else 'not yet':<9} {refresh:<12} "
            f"{_when(state.last_success_at if state else None):<17} {condition}"
        )
    if args.health:
        print()
        for config in registry.enabled(settings):
            adapter = create_adapter(config, settings)
            if adapter is None:
                print(f"{config.id:<20} health: no adapter yet")
                continue
            try:
                health = adapter.health_check()
            finally:
                adapter.close()
            latency = f" {health.latency_ms:.0f} ms" if health.latency_ms is not None else ""
            print(f"{config.id:<20} health: {health.status.value}{latency} {health.message}")
    return EXIT_OK


def cmd_fetch(args: argparse.Namespace) -> int:
    """Collect enabled sources once."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    try:
        report = fetch_all_enabled_sources(
            settings,
            create_session_factory(engine),
            sources=args.source or None,
            mode="full" if args.full else "auto",
            dry_run=args.dry_run,
            allow_mixed=args.allow_mixed,
        )
    except MixedDataError as exc:
        print(f"error: {exc}")
        return EXIT_FAILURE
    except KeyError as exc:
        print(f"error: {exc.args[0]}")
        return EXIT_CONFIG
    title = "Fetch (dry run, nothing written)" if report.dry_run else f"Fetch {report.job_id[:8]}"
    print(title)
    verb = "would insert" if report.dry_run else "inserted"
    for result in report.results:
        if result.status is RunStatus.SKIPPED:
            detail = "; ".join(result.warnings)
        else:
            detail = (
                f"{result.records_received} received, {result.records_inserted} {verb}, "
                f"{result.records_updated} updated, {result.records_skipped} unchanged, "
                f"{result.error_count} errors"
            )
        print(f"  {result.source_name:<20} {result.status.value:<9} {detail}")
        for message in result.errors[:3]:
            print(f"  {'':<20} ! {message}")
    ran = sum(1 for r in report.results if r.status is not RunStatus.SKIPPED)
    print(f"Result: {report.status.value} ({ran} of {len(report.results)} source(s) ran)")
    return EXIT_FAILURE if report.status in (RunStatus.FAILED, RunStatus.PARTIAL) else EXIT_OK


def cmd_normalize(args: argparse.Namespace) -> int:
    """Resolve organizations, assign topics and mark cross-source duplicates."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    taxonomy = load_taxonomy(settings.topic_taxonomy_file)
    factory = create_session_factory(engine)

    def progress(done: int, total: int) -> None:
        print(f"\r  {done}/{total} records...", end="", flush=True)

    with session_scope(factory) as session:
        sync_taxonomy(session, taxonomy)
        if args.reprocess:
            print(f"marking {reset_normalization(session)} record(s) for reprocessing")
        summary = normalize_records(
            session,
            settings,
            taxonomy,
            limit=args.limit,
            reprocess=args.reprocess,
            deduplicate=not args.no_dedupe,
            progress=progress,
        )
    print("\r" + " " * 40)
    print(f"normalized {summary.records_processed} record(s)")
    print(
        f"  organizations   : {summary.organizations_created} new, "
        f"{summary.organization_links} link(s)"
    )
    print(
        f"  topics          : {summary.topic_links} assignment(s), "
        f"{summary.records_without_topic} record(s) matched no topic"
    )
    print(f"  duplicates      : {summary.duplicates_marked} marked as copies of another source")
    print(f"  needs review    : {summary.review_items} (see: cews review)")
    if summary.failures:
        print(f"  failures        : {summary.failures} (see the log)")
    if summary.by_match_method:
        methods = ", ".join(f"{k}={v}" for k, v in sorted(summary.by_match_method.items()))
        print(f"  name matching   : {methods}")
    return EXIT_OK


def _parse_as_of(value: str | None) -> datetime | None:
    """Read an --as-of date, or None for "now".

    Raises:
        ValueError: with a readable message for anything that is not YYYY-MM-DD.
    """
    if not value:
        return None
    try:
        return datetime.fromisoformat(value).replace(tzinfo=UTC)
    except ValueError as exc:
        raise ValueError(f"--as-of must be a date like 2026-08-31, got {value!r}") from exc


def cmd_features(args: argparse.Namespace) -> int:
    """Count activity into months and compute the features scoring will use."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    as_of = _parse_as_of(args.as_of)
    factory = create_session_factory(engine)
    with session_scope(factory) as session:
        synthetic = count_records_by_origin(session)["synthetic"] > 0
        counted = aggregate_monthly_activity(
            session, as_of=as_of, rebuild=args.rebuild, is_synthetic=synthetic
        )
        run = compute_features(session, settings, as_of=as_of, is_synthetic=synthetic)

    if args.json:
        print(json.dumps({"activity": counted.as_dict(), "features": run.as_dict()}, indent=2))
        return EXIT_OK

    print(
        f"activity: {counted.records_counted} record(s) over {counted.months} month(s) "
        f"({counted.first_period} to {counted.last_period})"
    )
    print(
        f"  periods : {counted.rows_written} written, {counted.rows_updated} updated"
        + (f", {counted.rows_removed} removed" if counted.rows_removed else "")
    )
    for warning in [*counted.warnings, *run.warnings]:
        print(f"  note    : {warning}")
    if not run.entities:
        print("no topics or competitors with activity yet; run: cews normalize, cews competitors")
        return EXIT_OK

    print(
        f"\nfeatures for {run.feature_date} over {run.months} month(s): {run.values_written} written, "
        f"{run.values_updated} updated"
    )
    if run.skipped_no_data:
        print(
            f"  no activity : {', '.join(run.skipped_no_data[:6])}"
            + (" ..." if len(run.skipped_no_data) > 6 else "")
        )
    if run.skipped_low_sample:
        print(f"  thin evidence: {', '.join(run.skipped_low_sample)} (kept, but low confidence)")

    ranked = sorted(
        run.entities,
        key=lambda entity: (entity.velocity.slope if entity.velocity else 0.0),
        reverse=True,
    )[: args.top]
    print(
        f"\n{'entity':<34} {'kind':<10} {'velocity':>9} {'momentum':>9} {'steady':>7} {'records':>8} {'conf':>5}"
    )
    print("-" * 92)
    for entity in ranked:
        velocity = f"{entity.velocity.slope:+.3f}" if entity.velocity else "n/a"
        steady = f"{entity.consistency.consistency:.2f}" if entity.consistency else "n/a"
        print(
            f"{entity.name[:33]:<34} {entity.entity_type:<10} {velocity:>9} "
            f"{entity.momentum.momentum:>+9.3f} {steady:>7} {entity.total_records:>8.0f} "
            f"{entity.sample_confidence:>5.2f}"
        )
    print("\nvelocity is the fitted monthly trend; conf is how much the sample size supports it")
    return EXIT_OK


def cmd_score(args: argparse.Namespace) -> int:
    """Score the stored features and save the results with their breakdown."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    as_of = _parse_as_of(args.as_of)
    factory = create_session_factory(engine)
    with session_scope(factory) as session:
        synthetic = count_records_by_origin(session)["synthetic"] > 0
        run = run_scoring(
            session, settings, as_of=as_of, store=not args.no_store, is_synthetic=synthetic
        )
        rows: list[dict[str, Any]] = [
            {
                "entity": result.entity_name,
                "kind": result.entity_type,
                "score_type": result.score_type,
                "score": round(result.value, 2),
                "confidence": round(result.confidence, 2),
                "category": result.category,
                "records": round(result.sample_size),
                "qualifies": result.qualified,
                "failed_rules": list(result.failed_gates),
                "missing_inputs": list(result.unavailable),
                "explanation": result.explain(),
            }
            for result in run.results
        ]

    if args.json:
        print(json.dumps({"run": run.as_dict(), "results": rows}, indent=2))
        return EXIT_OK

    for warning in run.warnings:
        print(f"note: {warning}")
    if not run.results:
        return EXIT_OK

    print(
        f"scored {run.score_date} with weights version {run.version}: "
        f"{len(run.results)} result(s), {run.stored.written} written, "
        f"{run.stored.updated} updated"
        + (f", {run.stored.removed} removed" if run.stored.removed else "")
    )

    if args.low_confidence:
        doubtful = sorted(
            (row for row in rows if row["confidence"] < LOW_CONFIDENCE),
            key=lambda row: row["confidence"],
        )
        _print_score_table("Results that should not be acted on", doubtful[: args.top])
        return EXIT_OK

    wanted = args.type
    if wanted in ("all", "trend"):
        trends = [row for row in rows if row["score_type"] == "trend"]
        qualified = [row["entity"] for row in trends if row["qualifies"]]
        print(
            "\nEmerging trends (passed every rule): "
            + (", ".join(qualified) if qualified else "none")
        )
        _print_score_table(
            "Topics by trend score", sorted(trends, key=lambda row: -row["score"])[: args.top]
        )
    if wanted in ("all", "opportunity"):
        opportunities = [row for row in rows if row["score_type"] == "opportunity"]
        _print_score_table(
            "Topics by opportunity score (prioritization only, not a recommendation)",
            sorted(opportunities, key=lambda row: -row["score"])[: args.top],
        )
    if wanted == "confidence":
        _print_score_table(
            "Confidence in each result",
            sorted(
                (row for row in rows if row["score_type"] == "confidence"),
                key=lambda row: -row["score"],
            )[: args.top],
        )
    print(
        "\nA score alone is never a finding: a topic must also clear confidence, evidence,\n"
        "independent-source and single-spike rules. 'why not' names the rules it failed."
    )
    return EXIT_OK


def _print_score_table(title: str, rows: Sequence[dict[str, Any]]) -> None:
    """Print one block of scores with the reasons any of them do not qualify."""
    print(f"\n{title}")
    print(f"{'entity':<30} {'score':>6} {'conf':>6} {'category':<28} {'ok':<4} why not")
    print("-" * 110)
    if not rows:
        print("(none)")
        return
    for row in rows:
        why = ", ".join(rule.replace("_", " ") for rule in row["failed_rules"])
        if row["missing_inputs"]:
            missing = ", ".join(name.replace("_", " ") for name in row["missing_inputs"])
            why = (why + "; " if why else "") + f"no {missing}"
        mark = "yes" if row["qualifies"] else "no"
        print(
            f"{row['entity'][:29]:<30} {row['score']:>6.1f} {row['confidence']:>6.1f} "
            f"{row['category'][:27]:<28} {mark:<4} {why[:45]}"
        )


def cmd_competitors(args: argparse.Namespace) -> int:
    """Rank organizations and show the competitors CEWS is monitoring."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    with session_scope(create_session_factory(engine)) as session:
        result = discover_competitors(
            session,
            settings,
            window_months=args.window_months,
            include_all_types=args.include_all_types,
            persist=not args.no_persist,
        )
        if args.json:
            print(json.dumps(result.as_dict(), indent=2))
            return EXIT_OK
        window = result.window_start.date() if result.window_start else "-"
        print(f"mode {result.plan.mode.value if result.plan else '-'}, activity since {window}")
        if result.weights:
            print("weights: " + ", ".join(f"{k} {v}" for k, v in result.weights.items()))
        for warning in result.warnings:
            print(f"  note: {warning}")
        if not result.monitored:
            print("\nno competitors yet; collect data and run: cews normalize")
            return EXIT_OK
        print(f"\n{'competitor':32} {'score':>6} {'records':>8}  source types")
        print("-" * 78)
        for entry in result.monitored:
            mark = "*" if entry.manually_included else " "
            sources = ", ".join(s.replace("clinical_trial", "trial") for s in entry.source_types)
            print(
                f"{mark} {entry.name[:30]:30} {entry.score:6.1f} {entry.evidence_count:8}  {sources}"
            )
        print("\n* from COMPETITOR_INCLUDE; the rest were discovered from the data")
    return EXIT_OK


def cmd_review(args: argparse.Namespace) -> int:
    """Show the entity decisions CEWS would not make on its own."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    with session_scope(create_session_factory(engine)) as session:
        items = list(
            session.scalars(
                select(ReviewQueueItem)
                .where(ReviewQueueItem.status == "pending")
                .order_by(ReviewQueueItem.queue_type, ReviewQueueItem.id)
                .limit(args.limit)
            )
        )
        if not items:
            print("nothing waiting for review")
            return EXIT_OK
        print(f"{len(items)} item(s) awaiting review\n")
        for item in items:
            payload = item.payload_json or {}
            subject = payload.get("organizations") or payload.get("raw_name") or item.subject_ref
            print(f"[{item.queue_type}] {subject}")
            print(f"    reason : {payload.get('reason', '-')}")
            for key in ("candidates", "similar_to", "linked_to", "similarity", "action"):
                if payload.get(key) is not None:
                    print(f"    {key:7}: {payload[key]}")
    return EXIT_OK


# --------------------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    """Create the argument parser. ``--env-file`` and ``-v`` are accepted after the command."""
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "--env-file", help="dotenv file to load (default: .env in the project root)"
    )
    common.add_argument(
        "-v", "--verbose", action="store_true", help="show informational log output"
    )

    parser = argparse.ArgumentParser(prog="cews", description="Competitor Early Warning System")
    parser.add_argument("--version", action="version", version=f"cews {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser(
        "check-env", parents=[common], help="validate configuration, packages and database"
    ).set_defaults(func=cmd_check_env)
    init = sub.add_parser(
        "db-init", parents=[common], help="create/upgrade the schema and load the taxonomy"
    )
    init.add_argument("--no-taxonomy", action="store_true", help="skip loading the taxonomy file")
    init.set_defaults(func=cmd_db_init)
    sub.add_parser(
        "db-status", parents=[common], help="show schema revision and record counts"
    ).set_defaults(func=cmd_db_status)
    seed = sub.add_parser("seed-demo", parents=[common], help="load synthetic demo data")
    seed.add_argument("--seed", type=int, default=42, help="random seed (default 42)")
    seed.add_argument("--months", type=int, default=30, help="months of history (12-120)")
    seed.add_argument("--scale", type=float, default=1.0, help="activity multiplier (0.05-10)")
    seed.add_argument(
        "--write-fixtures",
        nargs="?",
        const="data/samples/demo",
        metavar="DIR",
        help="also write JSONL fixture files (default dir: data/samples/demo)",
    )
    seed.add_argument(
        "--allow-mixed",
        action="store_true",
        help="allow loading demo data into a database that holds live records",
    )
    seed.set_defaults(func=cmd_seed_demo)
    sources = sub.add_parser(
        "sources", parents=[common], help="list sources, adapters, checkpoints and circuit state"
    )
    sources.add_argument("--health", action="store_true", help="also contact each enabled source")
    sources.set_defaults(func=cmd_sources)
    fetch = sub.add_parser("fetch", parents=[common], help="collect enabled sources once")
    fetch.add_argument(
        "--source", action="append", metavar="ID", help="only this source (repeatable)"
    )
    fetch.add_argument("--dry-run", action="store_true", help="fetch and parse but write nothing")
    fetch.add_argument(
        "--full", action="store_true", help="ignore checkpoints; collect the full lookback"
    )
    fetch.add_argument(
        "--allow-mixed",
        action="store_true",
        help="allow writing live records into a database that holds demo data",
    )
    fetch.set_defaults(func=cmd_fetch)
    normalize = sub.add_parser(
        "normalize", parents=[common], help="resolve organizations and assign topics"
    )
    normalize.add_argument("--limit", type=int, help="process at most this many records")
    normalize.add_argument(
        "--reprocess", action="store_true", help="redo records that were already normalized"
    )
    normalize.add_argument(
        "--no-dedupe", action="store_true", help="skip the cross-source duplicate pass"
    )
    normalize.set_defaults(func=cmd_normalize)

    features = sub.add_parser(
        "features", parents=[common], help="count activity and compute trend features"
    )
    features.add_argument("--as-of", help="compute as of this date (YYYY-MM-DD, default: today)")
    features.add_argument(
        "--rebuild", action="store_true", help="drop stored periods that no longer have records"
    )
    features.add_argument("--top", type=int, default=12, help="how many rows to show (default 12)")
    features.add_argument("--json", action="store_true", help="print the full summary as JSON")
    features.set_defaults(func=cmd_features)
    score = sub.add_parser("score", parents=[common], help="score the stored features")
    score.add_argument("--as-of", help="score the features on or before this date (YYYY-MM-DD)")
    score.add_argument("--top", type=int, default=15, help="how many rows to show (default 15)")
    score.add_argument(
        "--type",
        choices=("all", "trend", "opportunity", "confidence"),
        default="all",
        help="which scores to show (default all)",
    )
    score.add_argument(
        "--low-confidence", action="store_true", help="show only results below the threshold"
    )
    score.add_argument("--no-store", action="store_true", help="compute without saving")
    score.add_argument("--json", action="store_true", help="print the full breakdown as JSON")
    score.set_defaults(func=cmd_score)
    competitors = sub.add_parser(
        "competitors", parents=[common], help="rank and show the monitored competitors"
    )
    competitors.add_argument("--window-months", type=int, help="activity window (default 12)")
    competitors.add_argument(
        "--include-all-types",
        action="store_true",
        help="also rank universities, hospitals and agencies",
    )
    competitors.add_argument("--json", action="store_true", help="print the full breakdown as JSON")
    competitors.add_argument(
        "--no-persist", action="store_true", help="do not update the organization flags"
    )
    competitors.set_defaults(func=cmd_competitors)

    review = sub.add_parser("review", parents=[common], help="show items awaiting human review")
    review.add_argument("--limit", type=int, default=20, help="maximum items to show")
    review.set_defaults(func=cmd_review)

    reset = sub.add_parser("reset-demo", parents=[common], help="delete all synthetic data")
    reset.add_argument("--yes", action="store_true", help="confirm deletion")
    reset.set_defaults(func=cmd_reset_demo)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI and return the process exit code."""
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except SettingsError as exc:
        print(exc)
        return EXIT_CONFIG
    except ScoringConfigError as exc:
        print(f"scoring configuration problem: {exc}")
        return EXIT_CONFIG
    except (DatabaseError, TaxonomyError, RegistryError, ValueError) as exc:
        print(f"error: {exc}")
        return EXIT_FAILURE
    except BrokenPipeError:  # output piped into head, less and friends
        with contextlib.suppress(OSError):
            sys.stdout.close()
        return EXIT_OK
    finally:
        for engine in _created_engines:
            engine.dispose()
        _created_engines.clear()


if __name__ == "__main__":
    sys.exit(main())
