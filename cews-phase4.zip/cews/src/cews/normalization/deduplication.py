"""Record hashing and de-duplication helpers.

Phase 2 provides :func:`create_record_hash`, which drives change detection during upserts.
Cross-source de-duplication (DOI/PMID matching, near-duplicate titles) arrives in Phase 5.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from datetime import date, datetime
from typing import Any


def _json_default(value: Any) -> str:
    if isinstance(value, datetime | date):
        return value.isoformat()
    raise TypeError(f"cannot hash value of type {type(value).__name__}")


def _clean(text: str | None) -> str:
    return " ".join(text.split()) if text else ""


def create_record_hash(
    *,
    source: str,
    source_record_id: str,
    title: str | None = None,
    abstract: str | None = None,
    published_at: datetime | None = None,
    payload: Mapping[str, Any] | None = None,
) -> str:
    """Return a stable SHA-256 hex digest of a record's content.

    The digest changes when the title, abstract, publication time or payload changes, and
    is unaffected by whitespace differences and dictionary key order. Fetch time is not
    part of the hash, so re-fetching an unchanged record yields the same digest.

    Raises:
        ValueError: if ``source`` or ``source_record_id`` is empty.
        TypeError: if the payload contains values that cannot be serialized.
    """
    if not source or not source_record_id:
        raise ValueError("source and source_record_id are required to hash a record")
    canonical = json.dumps(
        {
            "source": source,
            "source_record_id": source_record_id,
            "title": _clean(title),
            "abstract": _clean(abstract),
            "published_at": published_at.isoformat() if published_at else None,
            "payload": dict(payload) if payload else {},
        },
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        default=_json_default,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
