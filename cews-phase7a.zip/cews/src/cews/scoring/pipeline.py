"""Running the scoring pass.

Reads the stored features for a date, produces scores, and saves them with their breakdown.

This phase computes the confidence score that every other score is shown beside. The analytical
scores (trend and opportunity for topics, innovation and threat for competitors) are added in the
next two phases and join the same pass, so they are computed from the same inputs, on the same
date, and stored the same way.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from cews.constants import ScoreType
from cews.database.models import Score
from cews.features.pipeline import load_feature_settings
from cews.scoring.base import Gate, ScoreResult
from cews.scoring.confidence_score import ConfidenceResult, calculate_confidence_score
from cews.scoring.config import ScoringConfig, load_scoring_config
from cews.scoring.inputs import EntityInputs, as_evidence, latest_feature_date, load_entity_inputs
from cews.scoring.store import StoreSummary, save_scores
from cews.settings import Settings

LOGGER = logging.getLogger(__name__)


@dataclass
class ScoringRun:
    """The outcome of one scoring pass."""

    score_date: date | None
    version: str
    results: list[ScoreResult] = field(default_factory=list)
    stored: StoreSummary = field(default_factory=StoreSummary)
    warnings: list[str] = field(default_factory=list)

    def of_type(self, score_type: str) -> list[ScoreResult]:
        """The results of one score type, highest first."""
        chosen = [result for result in self.results if result.score_type == score_type]
        return sorted(chosen, key=lambda result: result.value, reverse=True)

    def as_dict(self) -> dict[str, Any]:
        """JSON-friendly summary."""
        counts: dict[str, int] = {}
        for result in self.results:
            counts[result.score_type] = counts.get(result.score_type, 0) + 1
        return {
            "score_date": self.score_date.isoformat() if self.score_date else None,
            "scoring_version": self.version,
            "scores": counts,
            "low_confidence": sum(
                1 for result in self.results if result.confidence < LOW_CONFIDENCE_LIMIT
            ),
            "stored": self.stored.as_dict(),
            "warnings": list(self.warnings),
        }


LOW_CONFIDENCE_LIMIT = 60.0


def score_confidence(
    inputs: EntityInputs,
    config: ScoringConfig,
    *,
    as_of: datetime,
    half_life_days: float,
    minimum: float,
) -> tuple[ScoreResult, ConfidenceResult]:
    """The confidence score for one entity.

    Raises:
        ValueError: if a stored feature is outside the 0-1 range it is meant to hold.
    """
    confidence = calculate_confidence_score(
        sample_confidence=inputs.raw_value("sample_confidence", 0.0) or 0.0,
        source_agreement=inputs.raw_value("source_agreement", 0.0) or 0.0,
        data_completeness=inputs.raw_value("data_completeness", 0.0) or 0.0,
        data_freshness=inputs.freshness(as_of=as_of, half_life_days=half_life_days),
        model_stability=inputs.stability(),
        sample_size=inputs.sample_size,
        weights=config.weights("confidence_score"),
    )
    usable = Gate(
        name="usable_confidence",
        passed=confidence.value >= minimum,
        detail=(
            f"confidence {confidence.value:.0f} is below the {minimum:.0f} needed to treat a "
            "score as a finding"
        ),
    )
    notes: list[str] = []
    if "model_stability" in confidence.unavailable:
        notes.append(
            "Stability is unknown because this is the first scored run; its weight was shared "
            "across the other inputs rather than counted as zero."
        )
    result = ScoreResult(
        score_type=ScoreType.CONFIDENCE.value,
        entity_type=inputs.entity_type,
        entity_id=inputs.entity_id,
        entity_name=inputs.name,
        value=confidence.value,
        confidence=confidence.value,
        components=confidence.components,
        unavailable=confidence.unavailable,
        sample_size=inputs.sample_size,
        gates=(usable,),
        notes=notes,
        scoring_version=config.version,
    )
    return result, confidence


def run_scoring(
    session: Session,
    settings: Settings,
    *,
    as_of: datetime | date | None = None,
    store: bool = True,
    is_synthetic: bool = False,
) -> ScoringRun:
    """Score every entity that has features, and save the results.

    Args:
        as_of: score the most recent feature date on or before this point (default: now).
        store: write the scores to the database.
        is_synthetic: mark stored rows as demo data.

    Raises:
        ScoringConfigError: if the scoring configuration does not add up.
    """
    config = load_scoring_config(settings)
    options = load_feature_settings(settings)
    moment = as_of if isinstance(as_of, datetime) else None
    if moment is None:
        moment = (
            datetime(as_of.year, as_of.month, as_of.day, tzinfo=UTC)
            if isinstance(as_of, date)
            else datetime.now(UTC)
        )

    feature_date = latest_feature_date(session, on_or_before=moment.date())
    run = ScoringRun(score_date=feature_date, version=config.version)
    run.warnings.extend(config.warnings)
    if feature_date is None:
        run.warnings.append("no features stored yet; run: cews features")
        return run

    entities = load_entity_inputs(session, feature_date)
    if not entities:
        run.warnings.append(f"no features stored for {feature_date}; run: cews features")
        return run

    evidence: dict[tuple[str, int], Any] = {}
    for key, inputs in sorted(entities.items(), key=lambda item: item[0]):
        result, _ = score_confidence(
            inputs,
            config,
            as_of=moment,
            half_life_days=options.freshness_half_life_days,
            minimum=config.emerging_trend.min_confidence,
        )
        run.results.append(result)
        evidence[key] = as_evidence(inputs)

    if store:
        run.stored = save_scores(
            session,
            feature_date,
            run.results,
            evidence=evidence,
            is_synthetic=is_synthetic,
        )
    LOGGER.info("scoring pass: %s", run.as_dict())
    return run


def score_history(
    session: Session, entity_type: str, entity_id: int, score_type: str
) -> list[Score]:
    """Every stored score of one type for one entity, oldest first."""
    return list(
        session.scalars(
            select(Score)
            .where(
                Score.entity_type == entity_type,
                Score.entity_id == entity_id,
                Score.score_type == score_type,
            )
            .order_by(Score.score_date)
        )
    )
