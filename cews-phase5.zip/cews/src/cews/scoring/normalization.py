"""Putting raw feature values on a comparable 0-100 scale.

Counts from different sources cannot be added together: a topic with 400 publications and 3
trials is not "403 units" of activity. Each value is therefore ranked against a cohort of
comparable values first.

Percentile rank is the project default (``NORMALIZATION_METHOD``). It answers "where does this
value sit among its peers?", is unaffected by outliers, and is easy to explain. The remaining
methods from the scoring specification (winsorized min-max, robust z-score) arrive with the
scoring engine in Phase 6; this module provides what competitor discovery needs today.

Edge cases follow one rule: when a cohort cannot distinguish its members - it is empty, has one
member, or every value is identical - every member scores the neutral **50** rather than 0 or
100, because the data says nothing about who leads.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

NEUTRAL_SCORE = 50.0
SCORE_MIN = 0.0
SCORE_MAX = 100.0


def _usable(values: Sequence[float]) -> list[float] | None:
    numbers = [float(v) for v in values]
    if not numbers or any(math.isnan(v) or math.isinf(v) for v in numbers):
        return None
    if len(numbers) == 1 or len(set(numbers)) == 1:
        return None
    return numbers


def percentile_normalize(values: Sequence[float]) -> list[float]:
    """Rank each value against the cohort, as a 0-100 percentile.

    A value scores ``(below + half the ties) / count``, so the middle of a cohort lands near 50
    and ties share a score. Returns 50 for every member of a cohort that cannot rank itself.
    """
    numbers = _usable(values)
    if numbers is None:
        return [NEUTRAL_SCORE] * len(values)
    total = len(numbers)
    ordered = sorted(numbers)
    scores: list[float] = []
    for value in numbers:
        below = sum(1 for other in ordered if other < value)
        ties = sum(1 for other in ordered if other == value)
        scores.append(round((below + 0.5 * ties) / total * 100, 4))
    return scores


def minmax_normalize(values: Sequence[float]) -> list[float]:
    """Scale values linearly so the smallest is 0 and the largest is 100.

    Useful for display, but sensitive to outliers; percentile rank is preferred for scoring.
    """
    numbers = _usable(values)
    if numbers is None:
        return [NEUTRAL_SCORE] * len(values)
    low, high = min(numbers), max(numbers)
    span = high - low
    return [round((value - low) / span * 100, 4) for value in numbers]


def normalize_values(values: Sequence[float], method: str = "percentile") -> list[float]:
    """Normalize with the named method.

    Raises:
        ValueError: for a method this module does not implement yet.
    """
    if method == "percentile":
        return percentile_normalize(values)
    if method == "minmax":
        return minmax_normalize(values)
    raise ValueError(
        f"normalization method {method!r} is not available yet; use 'percentile' or 'minmax'"
    )


def clamp_score(value: float) -> float:
    """Keep a score inside 0-100."""
    return max(SCORE_MIN, min(SCORE_MAX, float(value)))


def renormalize_weights(weights: dict[str, float], available: Sequence[str]) -> dict[str, float]:
    """Spread the weights of unavailable components across the ones that remain.

    A missing source is never treated as zero activity: its weight is redistributed in
    proportion, so the score still ranges 0-100 and the components that do exist keep their
    relative importance. Confidence is lowered separately by the caller.

    Raises:
        ValueError: if none of the components are available or the weights are not positive.
    """
    usable = {name: float(weights[name]) for name in available if name in weights}
    if not usable or sum(usable.values()) <= 0:
        raise ValueError("no weighted components are available")
    total = sum(usable.values())
    return {name: weight / total for name, weight in usable.items()}
