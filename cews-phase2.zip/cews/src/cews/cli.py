"""Command-line interface for CEWS.

Commands (also available as ``python scripts/<name>.py`` wrappers)::

    cews check-env                 validate configuration, packages and database access
    cews db-init                   create/upgrade the database schema and load the taxonomy
    cews db-status                 show schema revision and record counts
    cews seed-demo                 load deterministic synthetic demo data
    cews reset-demo --yes          delete all synthetic data (live data is never touched)

Exit codes: 0 success, 1 runtime failure, 2 configuration or usage problem.
"""

from __future__ import annotations

import argparse
import importlib
import logging
import sys
from collections.abc import Sequence
from pathlib import Path

from sqlalchemy import Engine, func, inspect, select

from cews import __version__
from cews.constants import DatabaseBackend
from cews.database.connection import (
    DatabaseError,
    build_database_url,
    create_db_engine,
    create_session_factory,
    database_is_initialized,
    describe_url,
    session_scope,
)
from cews.database.migrations import current_revision, head_revision, upgrade_database
from cews.database.models import IngestionRun, Topic
from cews.database.repositories import (
    MixedDataError,
    count_records_by_origin,
    reset_synthetic_data,
)
from cews.demo.generator import DemoConfig, generate_demo_dataset, write_fixtures
from cews.demo.loader import load_demo_dataset
from cews.logging_config import configure_logging
from cews.normalization.topics import TaxonomyError, load_taxonomy, sync_taxonomy
from cews.settings import (
    Settings,
    SettingsError,
    load_settings,
    resolve_competitor_mode,
    validate_settings,
)

EXIT_OK, EXIT_FAILURE, EXIT_CONFIG = 0, 1, 2
REQUIRED_PACKAGES = ("pydantic", "pydantic_settings", "sqlalchemy", "alembic", "yaml", "tzdata")
MIN_PYTHON = (3, 11)


def _load(args: argparse.Namespace) -> Settings:
    settings = load_settings(env_file=args.env_file) if args.env_file else load_settings()
    configure_logging(settings)
    if not args.verbose:
        for handler in logging.getLogger("cews").handlers:
            if isinstance(handler, logging.StreamHandler) and not isinstance(
                handler, logging.FileHandler
            ):
                handler.setLevel(logging.WARNING)
    return settings


_created_engines: list[Engine] = []


def _engine(settings: Settings) -> Engine:
    """Create an engine that ``main`` disposes when the command finishes."""
    engine = create_db_engine(settings)
    _created_engines.append(engine)
    return engine


# --------------------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------------------
def cmd_check_env(args: argparse.Namespace) -> int:
    """Validate Python, packages, configuration and database reachability."""
    failures = 0

    def report(level: str, message: str) -> None:
        nonlocal failures
        if level == "fail":
            failures += 1
        print(f"[{level:>4}] {message}")

    version = sys.version_info
    if (version.major, version.minor) >= MIN_PYTHON:
        report("ok", f"Python {version.major}.{version.minor}.{version.micro}")
    else:
        report("fail", f"Python {version.major}.{version.minor} found; 3.11 or newer is required")
    for package in REQUIRED_PACKAGES:
        try:
            importlib.import_module(package)
        except ImportError:
            report(
                "fail",
                f"package '{package}' is not installed (python -m pip install -r requirements-dev.txt)",
            )
    if failures:
        return EXIT_CONFIG

    try:
        settings = _load(args)
        warnings = validate_settings(settings)
        plan = resolve_competitor_mode(settings)
    except SettingsError as exc:
        print(exc)
        return EXIT_CONFIG
    report("ok", "configuration is valid")
    report(
        "ok",
        f"fetch interval {settings.fetch_interval_minutes} minutes, scheduler "
        f"{'on' if settings.enable_scheduler else 'off'}",
    )
    report(
        "ok",
        f"competitor mode {plan.mode.value}: {len(plan.include)} fixed, "
        f"{plan.auto_slots} automatic slot(s)",
    )
    report("ok", f"enabled sources: {', '.join(settings.enabled_sources) or 'none'}")
    for warning in warnings:
        report("warn", warning)

    url = build_database_url(settings)
    if settings.database_backend is DatabaseBackend.SQLITE and not Path(str(url.database)).exists():
        report("warn", f"SQLite database not created yet ({describe_url(url)}); run db-init")
    else:
        try:
            engine = _engine(settings)
            with engine.connect():
                pass
            report("ok", f"database reachable ({describe_url(url)})")
        except Exception as exc:  # any driver error is a failed check
            report("fail", f"cannot connect to {describe_url(url)}: {exc}")
    return EXIT_FAILURE if failures else EXIT_OK


def cmd_db_init(args: argparse.Namespace) -> int:
    """Create or upgrade the schema, then load the topic taxonomy."""
    settings = _load(args)
    engine = _engine(settings)
    revision = upgrade_database(engine)
    print(f"database schema at revision {revision} ({describe_url(build_database_url(settings))})")
    if not args.no_taxonomy:
        taxonomy = load_taxonomy(settings.topic_taxonomy_file)
        with session_scope(create_session_factory(engine)) as session:
            summary = sync_taxonomy(session, taxonomy)
        print(
            f"taxonomy loaded: {summary.topics_created} topic(s) and {summary.areas_created} area(s) "
            f"created, {summary.aliases_created} alias(es) added"
        )
    return EXIT_OK


def cmd_db_status(args: argparse.Namespace) -> int:
    """Print schema revision and record counts."""
    settings = _load(args)
    engine = _engine(settings)
    url = describe_url(build_database_url(settings))
    if not database_is_initialized(engine):
        print(f"database not initialized ({url}); run db-init")
        return EXIT_FAILURE
    revision, head = current_revision(engine), head_revision()
    state = "up to date" if revision == head else f"behind head {head}; run db-init"
    print(f"database : {url}")
    print(f"revision : {revision} ({state})")
    print(f"tables   : {len(inspect(engine).get_table_names()) - 1}")
    with session_scope(create_session_factory(engine)) as session:
        counts = count_records_by_origin(session)
        print(f"records  : {counts['synthetic']} synthetic, {counts['live']} live")
        print(f"topics   : {session.scalar(select(func.count()).select_from(Topic))}")
        last = session.scalars(
            select(IngestionRun).order_by(IngestionRun.start_time.desc())
        ).first()
        if last is not None:
            print(f"last run : {last.source} {last.status} at {last.start_time.isoformat()}")
    return EXIT_OK


def cmd_seed_demo(args: argparse.Namespace) -> int:
    """Generate and load the synthetic demo dataset (idempotent)."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; run db-init first")
        return EXIT_FAILURE
    config = DemoConfig(seed=args.seed, months=args.months, scale=args.scale)
    dataset = generate_demo_dataset(config)
    taxonomy = load_taxonomy(settings.topic_taxonomy_file)
    try:
        with session_scope(create_session_factory(engine)) as session:
            sync_taxonomy(session, taxonomy)
            summary = load_demo_dataset(session, dataset, allow_mixed=args.allow_mixed)
    except MixedDataError as exc:
        print(f"error: {exc}")
        return EXIT_FAILURE
    print("SYNTHETIC demo data loaded (invented organizations and artificial patterns)")
    print(
        f"  records: {summary.total} ({summary.inserted} inserted, {summary.updated} updated, "
        f"{summary.unchanged} unchanged)"
    )
    print(f"  by type: {dataset.count_by_type()}")
    print(f"  months : {dataset.months[0].isoformat()} to {dataset.months[-1].isoformat()}")
    if args.write_fixtures is not None:
        directory = Path(args.write_fixtures).expanduser()
        if not directory.is_absolute():
            directory = settings.project_root / directory
        written = write_fixtures(dataset, directory)
        print(f"  fixtures: {len(written)} files written to {directory}")
    return EXIT_OK


def cmd_reset_demo(args: argparse.Namespace) -> int:
    """Delete all synthetic rows. Live data is never touched."""
    settings = _load(args)
    engine = _engine(settings)
    if not database_is_initialized(engine):
        print("database not initialized; nothing to reset")
        return EXIT_OK
    factory = create_session_factory(engine)
    with session_scope(factory) as session:
        counts = count_records_by_origin(session)
    if not args.yes:
        print(
            f"This deletes {counts['synthetic']} synthetic records and all derived synthetic rows "
            f"({counts['live']} live records are kept). Re-run with --yes to confirm."
        )
        return EXIT_CONFIG
    with session_scope(factory) as session:
        removed = reset_synthetic_data(session)
    print("removed:", ", ".join(f"{name}={count}" for name, count in removed.items() if count))
    return EXIT_OK


# --------------------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    """Create the argument parser. ``--env-file`` and ``-v`` are accepted after the command."""
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "--env-file", help="dotenv file to load (default: .env in the project root)"
    )
    common.add_argument(
        "-v", "--verbose", action="store_true", help="show informational log output"
    )

    parser = argparse.ArgumentParser(prog="cews", description="Competitor Early Warning System")
    parser.add_argument("--version", action="version", version=f"cews {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser(
        "check-env", parents=[common], help="validate configuration, packages and database"
    ).set_defaults(func=cmd_check_env)
    init = sub.add_parser(
        "db-init", parents=[common], help="create/upgrade the schema and load the taxonomy"
    )
    init.add_argument("--no-taxonomy", action="store_true", help="skip loading the taxonomy file")
    init.set_defaults(func=cmd_db_init)
    sub.add_parser(
        "db-status", parents=[common], help="show schema revision and record counts"
    ).set_defaults(func=cmd_db_status)
    seed = sub.add_parser("seed-demo", parents=[common], help="load synthetic demo data")
    seed.add_argument("--seed", type=int, default=42, help="random seed (default 42)")
    seed.add_argument("--months", type=int, default=30, help="months of history (12-120)")
    seed.add_argument("--scale", type=float, default=1.0, help="activity multiplier (0.05-10)")
    seed.add_argument(
        "--write-fixtures",
        nargs="?",
        const="data/samples/demo",
        metavar="DIR",
        help="also write JSONL fixture files (default dir: data/samples/demo)",
    )
    seed.add_argument(
        "--allow-mixed",
        action="store_true",
        help="allow loading demo data into a database that holds live records",
    )
    seed.set_defaults(func=cmd_seed_demo)
    reset = sub.add_parser("reset-demo", parents=[common], help="delete all synthetic data")
    reset.add_argument("--yes", action="store_true", help="confirm deletion")
    reset.set_defaults(func=cmd_reset_demo)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI and return the process exit code."""
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except SettingsError as exc:
        print(exc)
        return EXIT_CONFIG
    except (DatabaseError, TaxonomyError, ValueError) as exc:
        print(f"error: {exc}")
        return EXIT_FAILURE
    finally:
        for engine in _created_engines:
            engine.dispose()
        _created_engines.clear()


if __name__ == "__main__":
    sys.exit(main())
