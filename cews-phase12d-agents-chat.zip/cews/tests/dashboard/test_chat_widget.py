"""Tests for the floating chat widget, using Streamlit's own test harness.

These run the real ``app.py`` (through ``AppTest``, the same tool ``test_app.py`` uses for the
other seven pages) so a script-level mistake - the widget never being called, the toggle wiring
breaking, the "not configured" message vanishing - is caught the same way a break in any other
page would be. They cannot check the actual floating position in a browser; that was verified
separately by rendering the real dashboard in a headless browser and reading the button's
computed CSS position directly (see ``docs/agents.md`` for what was checked and how).

Monkeypatching ``chat_widget._runtime`` before ``AppTest.run()`` is what lets the "LLM
configured" tests inject a real in-process MCP session (no subprocess) and a mocked LLM
transport, instead of every test needing a live model: confirmed to actually take effect across
an ``AppTest`` run before relying on it here.
"""

from __future__ import annotations

import sys
from collections.abc import Callable
from pathlib import Path

import httpx
import pytest
from streamlit.testing.v1 import AppTest
from streamlit.testing.v1.element_tree import Button

pytestmark = pytest.mark.integration

APP = Path(__file__).resolve().parents[2] / "dashboards" / "streamlit" / "app.py"
# Import exactly the way app.py itself does ("from components import chat_widget", with
# app.py's own directory on sys.path) so this file's `chat_widget` and app.py's are the *same*
# module object under the same sys.modules key. Setting up sys.path differently here - e.g.
# adding the components/ directory itself and doing a bare "import chat_widget" - registers a
# second, distinct module under a different name, and patching that one has no effect on what
# app.py actually calls; this was caught by a test that silently launched a real subprocess
# instead of using the mocked LLM, rather than by any static check.
if str(APP.parent) not in sys.path:
    sys.path.insert(0, str(APP.parent))


def _click(app: AppTest, key: str) -> Button:
    """``get_by_key`` returns a plain ``Node``; every key used here names a real button."""
    widget = app.get_by_key(key)
    assert isinstance(widget, Button), f"{key!r} is not a button: {type(widget)}"
    return widget.click()


def start(env_file: Path) -> AppTest:
    app = AppTest.from_file(str(APP), default_timeout=120)
    app.session_state["env_file"] = str(env_file)
    return app.run()


def with_llm_configured(env_file: Path) -> Path:
    """A copy of ``env_file`` with an LLM provider declared.

    ``render()`` checks ``llm_enabled(settings)`` - read from the real env file, not from
    ``_runtime`` - before it ever calls ``_runtime`` at all, so a test that wants to reach the
    mocked-LLM path needs a provider actually set here; ``patch_runtime`` below only replaces
    what that provider then talks to.
    """
    configured = env_file.with_name("with_llm.env")
    configured.write_text(
        env_file.read_text(encoding="utf-8") + "\nLLM_PROVIDER=ollama\nLLM_BASE_URL=http://x/v1\n",
        encoding="utf-8",
    )
    return configured


def patch_runtime(
    monkeypatch: pytest.MonkeyPatch, *, handler: Callable[[httpx.Request], httpx.Response]
) -> None:
    """Make the widget's cached runtime use a real in-process MCP session and a mocked LLM.

    Imported here, not at module scope, so a test file that never calls this never needs the
    dashboard's own database/MCP fixtures at collection time.
    """
    from components import chat_widget
    from mcp.shared.memory import create_connected_server_and_client_session
    from sqlalchemy.orm import sessionmaker

    from cews.agents.session import AgentRuntime
    from cews.ai.llm import LLMClient
    from cews.database.connection import create_db_engine, create_session_factory
    from cews.mcp_server.server import build_server
    from cews.settings import load_settings

    def fake_runtime(env_file: str) -> AgentRuntime:
        settings = load_settings(env_file=env_file or None)
        factory: sessionmaker = create_session_factory(create_db_engine(settings))
        server = build_server(settings, factory)
        llm_settings = load_settings(
            env_file=env_file or None,
            overrides={"llm_provider": "ollama", "llm_base_url": "http://x/v1"},
        )
        runtime = AgentRuntime(
            settings,
            session_factory=lambda: create_connected_server_and_client_session(server),
            llm_client_factory=lambda: LLMClient(
                llm_settings, transport=httpx.MockTransport(handler)
            ),
        )
        runtime.start(timeout=15)
        return runtime

    monkeypatch.setattr(chat_widget, "_runtime", fake_runtime)


def text_only(content: str) -> Callable[[httpx.Request], httpx.Response]:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"choices": [{"message": {"content": content}}]})

    return handler


# --------------------------------------------------------------------------------------
# The widget is present and wired into the dashboard
# --------------------------------------------------------------------------------------
def test_the_toggle_button_is_on_every_page_load(env_file: Path) -> None:
    app = start(env_file)
    assert not app.exception
    assert app.get_by_key("cews_chat_toggle_button") is not None


def test_the_floating_css_is_injected(env_file: Path) -> None:
    """Only checks the style rules are present - actual floating position was verified by
    rendering the real dashboard in a headless browser, not by this test."""
    app = start(env_file)
    css = "".join(m.value for m in app.markdown)
    assert "st-key-cews-chat-toggle" in css and "position: fixed" in css


def test_the_panel_is_closed_by_default(env_file: Path) -> None:
    app = start(env_file)
    assert app.get_by_key("cews_chat_toggle_button") is not None
    # the panel's own contents (its heading) should not be findable in a fresh, unopened session
    assert not any("CEWS Analyst" in m.value for m in app.markdown)


def test_clicking_the_icon_opens_the_panel(env_file: Path) -> None:
    app = start(env_file)
    _click(app, "cews_chat_toggle_button").run()
    assert any("CEWS Analyst" in m.value for m in app.markdown)


def test_clicking_the_icon_twice_closes_it_again(env_file: Path) -> None:
    app = start(env_file)
    _click(app, "cews_chat_toggle_button").run()
    _click(app, "cews_chat_toggle_button").run()
    assert not any("CEWS Analyst" in m.value for m in app.markdown)


# --------------------------------------------------------------------------------------
# No LLM configured
# --------------------------------------------------------------------------------------
def test_with_no_llm_configured_the_panel_explains_that_instead_of_a_chat_box(
    env_file: Path,
) -> None:
    app = start(env_file)
    _click(app, "cews_chat_toggle_button").run()
    assert not app.exception
    assert any("No LLM is configured" in m.value for m in app.info)
    assert app.chat_input == []  # no chat box offered when nothing can answer it


# --------------------------------------------------------------------------------------
# A real (mocked-transport) exchange through the widget
# --------------------------------------------------------------------------------------
def test_a_question_gets_a_real_answer_through_the_widget(
    env_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    patch_runtime(monkeypatch, handler=text_only("Nothing is trending yet."))
    app = start(with_llm_configured(env_file))
    _click(app, "cews_chat_toggle_button").run()
    assert not app.exception
    assert len(app.chat_input) == 1

    app.chat_input[0].set_value("what's trending?").run()
    assert not app.exception
    messages = {m.name: m for m in app.chat_message}
    assert "user" in messages and "assistant" in messages
    assistant_text = "".join(el.value for el in messages["assistant"].markdown)
    assert "Nothing is trending yet." in assistant_text


def test_a_second_question_in_the_same_session_keeps_the_first_in_view(
    env_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    patch_runtime(monkeypatch, handler=text_only("answer"))
    app = start(with_llm_configured(env_file))
    _click(app, "cews_chat_toggle_button").run()
    app.chat_input[0].set_value("first question").run()
    app.chat_input[0].set_value("second question").run()
    user_texts = [
        "".join(el.value for el in m.markdown) for m in app.chat_message if m.name == "user"
    ]
    assert "first question" in user_texts and "second question" in user_texts


def test_clear_conversation_empties_the_history(
    env_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    patch_runtime(monkeypatch, handler=text_only("answer"))
    app = start(with_llm_configured(env_file))
    _click(app, "cews_chat_toggle_button").run()
    app.chat_input[0].set_value("a question").run()
    assert any(m.name == "user" for m in app.chat_message)

    _click(app, "cews_chat_clear").run()
    assert not any(m.name == "user" for m in app.chat_message)
