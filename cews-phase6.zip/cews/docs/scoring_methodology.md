# Scoring methodology

Status: the activity features are built (Phase 6). The scores that combine them (trend,
innovation, threat, opportunity, confidence) arrive in Phase 7.

Run the feature pass with:

```
python -m cews.cli features                 # count activity, compute and store features
python -m cews.cli features --as-of 2026-08-31 --json
python -m cews.cli features --rebuild       # drop stored periods that no longer have records
```

## Counting activity

Records are counted into whole months per topic, per competitor, per competitor-within-topic and
overall, for each source type. Quarters and years are summed from the months, so the periods
always agree. **The month in progress is excluded**, because a part-finished month looks like a
collapse in activity.

Two numbers are stored per bucket:

- `activity_count` - how many records there were, which is what people recognise;
- `weighted_activity` - the sum of link confidence, so weaker evidence counts for less. A
  sponsored trial counts fully; an author's affiliation counts half, because a paper by someone
  at a company is not proof the company ran the work. **Scoring uses the weighted figure.**

Counting happens in the database, and re-running it rewrites the same rows rather than adding
more.

## The features

Every topic and monitored competitor gets a 12-month series per source type, and from it:

| Feature | What it answers | How |
|---|---|---|
| Growth | Did activity rise between two periods? | `ln((current + 1) / (previous + 1))` |
| Momentum | Is it heating up right now? | The same ratio, last 3 months against the 3 before |
| Velocity | Which way has it gone all year? | Slope of a line fitted to `log1p` monthly counts |
| Consistency | Sustained, or one big month? | Share of month-to-month changes that were increases |
| Recent surge | Any sharp short-term jump? | The same ratio over consecutive quarters |
| Competition density | How crowded is this topic? | Effective number of competitors (inverse HHI), saturating |
| Source agreement | Do independent sources agree? | Share of sources with data that are growing |
| Sample confidence | Is there enough evidence? | `1 - exp(-N / 25)` |

### Why growth is a log ratio

Raw percentages are unusable on small counts: 1 record to 3 is "+200%" and means nothing. The
smoothed log ratio is symmetric (a halving is exactly the negative of a doubling), stays finite
when a period has no records at all, and is far less excitable about small numbers. The familiar
percentage is still reported, for display only.

### Why velocity is refused sometimes

Fitting a line through three points produces a confident-looking number with nothing behind it.
Velocity returns nothing below `velocity_min_observations` months (6 by default) rather than
guessing. R-squared is reported alongside the slope: a single spike gives a slope near zero and
an R-squared near zero, which is how a spike is told apart from a trend.

### Why a one-player field is not "crowded"

Density uses the *effective* number of competitors (the inverse of the concentration index), not
the raw count. Ten equal players count as ten; ten players where one holds most of the activity
count as barely more than one.

## Normalization

Raw features from different sources cannot be added together, so each value is ranked inside a
**cohort**: the same feature, the same entity kind, the same date. Topics are ranked against
topics, competitors against competitors.

Four methods are available (`NORMALIZATION_METHOD`):

- **percentile** (default) - rank within the cohort. Immune to outliers, since only order counts.
- **winsorized_minmax** - clip the extremes at the configured quantiles, then scale.
- **robust_zscore** - centre on the median, scale by the median absolute deviation.
- **minmax** - plain linear scaling. Included for comparison; one outlier flattens everything else.

Awkward cohorts are handled explicitly rather than crashing or inventing a rank: a cohort where
every value is equal, a cohort of one, an empty cohort, and non-finite values all score the
neutral **50**. Negative growth is ranked like any other value.

Entities with no activity at all in the window are left out of the ranking entirely: including an
empty topic would shift everyone else's percentile.

## What is stored

Each value is written to `feature_values` with its raw value, its normalized 0-100 position, the
method, the cohort and cohort size, and the sample size behind it. That is what the
explainability view reads, and what Phase 7 combines into scores.

## Settings

In `config/scoring_weights.yaml` under `features`: `alpha`, `momentum_recent_months`,
`momentum_previous_months`, `velocity_window_months`, `velocity_min_observations`,
`sample_saturation_k`, `freshness_half_life_days`. In `.env`: `NORMALIZATION_METHOD`,
`NORMALIZATION_WINSOR_LOWER` / `_UPPER`, `MIN_TOPIC_SAMPLE_SIZE`.

## Limitations

- Features describe what the collected data shows. A source that is disabled, rate-limited or
  blocked leaves a real gap; agreement and confidence report that, but cannot fill it.
- Monthly counts on small topics are noisy. A topic with six records can show spectacular
  momentum; sample confidence is what stops that being read as a trend.
- Demo data is synthetic. Feature values computed from it prove the pipeline works, not that the
  scoring is valid.
